//
// Project: LeCrystal-HW6
// EID: CL44964
// Course: CS329E
//
//  CreatePizzaVC.swift
//  LeCrystal-HW5
//
//  Created by Crystal Le on 10/12/22.
//

import UIKit
//import FirebaseAuth

class CreatePizzaVC: UIViewController {
    
    var delegate: UIViewController! //delegate for main VC
    var pizzaResultString = "" //holds string to be displayed into table
    var currentPizza = EatPizza(pSize: "small", crust: "", cheese: "", meat: "", veggie: "")
    
    @IBAction func selectSize(_ sender: Any) {
        switch sizeButton.selectedSegmentIndex {
        case 0:
            currentPizza.pSize = "small"
        case 1:
            currentPizza.pSize = "medium"
        case 2:
            currentPizza.pSize = "large"
        default:
            currentPizza.pSize = "small" //default pizza is a small
        }
    }
    
    @IBAction func doneClick(_ sender: Any) {
        // check that all ingredients have been chosen if not show an error messsage
        if (currentPizza.crust == "") {
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: "Please select a crust type:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
        } else if (currentPizza.cheese == "") {
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: "Please select a cheeeze type:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
        } else if (currentPizza.meat == "") {
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: "Please select a meat:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
        } else if (currentPizza.veggie == ""){
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: "Please select a veggie:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
        } else {
            //if all ingrediens are not nil, display label with the summary of the order
            print(currentPizza.pSize)
            let result = "one \(currentPizza.pSize) pizza with:\n\t\(currentPizza.crust)\n\t\(currentPizza.cheese)\n\t\(currentPizza.meat)\n\t\(currentPizza.veggie)"
            pizzaResult.text = result
            let mainVC = delegate as! PizzaAdder
            mainVC.addPizza(newPizza: currentPizza)
        }
    }
    
    @IBOutlet weak var pizzaResult: UILabel!
    @IBOutlet weak var sizeButton: UISegmentedControl!
    
    @IBAction func selectCrust(_ sender: UIButton) {
        let controller = UIAlertController(
            title: "Select crust",
            message: "Choose a crust type:",
            preferredStyle: .alert)
        controller.addAction(UIAlertAction(
            title: "Thin crust",
            style: .default,
            handler: {(action) in self.currentPizza.crust = "thin crust"}))
        controller.addAction(UIAlertAction(
            title: "Thick crust",
            style: .default,
            handler: {(action) in self.currentPizza.crust = "thick crust"}))
        present(controller, animated: true)
    }
    
    @IBAction func selectVeggies(_ sender: UIButton) {
        let controller = UIAlertController(
            title: "Select veggie",
            message: "Choose your veggies:",
            preferredStyle: .actionSheet)
        controller.addAction(UIAlertAction(
            title: "Mushroom",
            style: .default,
            handler:{(action) in self.currentPizza.veggie = "mushroom"}))
        controller.addAction(UIAlertAction(
            title: "Onion",
            style: .default,
            handler: {(action) in self.currentPizza.veggie = "onion"}))
        controller.addAction(UIAlertAction(
            title: "Green Olive",
            style: .default,
            handler: {(action) in self.currentPizza.veggie = "green olive"}))
        controller.addAction(UIAlertAction(
            title: "Black Olive",
            style: .default,
            handler: {(action) in self.currentPizza.veggie = "black olive"}))
        controller.addAction(UIAlertAction(
            title: "None",
            style: .default,
            handler: {(action) in self.currentPizza.veggie = "none"}))
        present(controller, animated: true)
    }
    
    @IBAction func selectMeat(_ sender: UIButton) {
        let controller = UIAlertController(
            title: "Select meat",
            message: "Choose one meat:",
            preferredStyle: .actionSheet)
        controller.addAction(UIAlertAction(
            title: "Pepperoni",
            style: .default,
            handler:{(action) in self.currentPizza.meat = "pepperoni"}))
        controller.addAction(UIAlertAction(
            title: "Sausage",
            style: .default,
            handler: {(action) in self.currentPizza.meat = "sausage"}))
        controller.addAction(UIAlertAction(
            title: "Canadian Bacon",
            style: .default,
            handler: {(action) in self.currentPizza.meat = "canadian bacon"}))
        present(controller, animated: true)
    }
    
    @IBAction func selectCheese(_ sender: UIButton) {
        let controller = UIAlertController(
            title: "Select cheese",
            message: "Choose a cheese type:",
            preferredStyle: .actionSheet)
        controller.addAction(UIAlertAction(
            title: "Regular cheese",
            style: .default,
            handler:{(action) in self.currentPizza.cheese = "regular cheese"}))
        controller.addAction(UIAlertAction(
            title: "No cheese",
            style: .default,
            handler: {(action) in self.currentPizza.cheese = "no cheese"}))
        controller.addAction(UIAlertAction(
            title: "Double cheese",
            style: .default,
            handler: {(action) in self.currentPizza.cheese = "double cheese"}))
        present(controller, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pizzaResult.text = ""
    }
}
