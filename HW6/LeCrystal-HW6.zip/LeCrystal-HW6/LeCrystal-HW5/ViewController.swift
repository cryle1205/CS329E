//
// Project: LeCrystal-HW6
// EID: CL44964
// Course: CS329E
//
//  ViewController.swift
//  LeCrystal-HW5
//
//  Created by Crystal Le on 10/12/22.
//

import UIKit
import FirebaseAuth
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

//create empty array for pizza list
var pizzaList:[EatPizza] = []

//pizza class to hold variable properties of a pizza
class EatPizza {
    var pSize = ""
    var crust = ""
    var cheese = ""
    var meat = ""
    var veggie = ""
    
    init(pSize:String, crust:String, cheese:String, meat:String, veggie:String) {
        self.pSize = pSize
        self.crust = crust
        self.cheese = cheese
        self.meat = meat
        self.veggie = veggie
    }
}

//protocol to add Pizza
protocol PizzaAdder {
    func addPizza(newPizza:EatPizza)
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, PizzaAdder {

    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func logout(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            self.dismiss(animated: true)
        } catch {
            print ("Sign out error")
        }
    }
    let textCellIdentifier = "textCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        demoCoreData()
        // Do any additional setup after loading the view.
    }
    
    func demoCoreData() {
        pizzaList = []
        let fetchedResults = retrievePizza()
            for pizza in fetchedResults {
                if let pSize = pizza.value(forKey: "pSize") {
                    if let crust = pizza.value(forKey: "crust") {
                        if let cheese = pizza.value(forKey: "cheese") {
                            if let meat = pizza.value(forKey: "meat") {
                                if let veggie = pizza.value(forKey: "veggie") {
                                    pizzaList.append(EatPizza(pSize: "\(pSize)", crust: "\(crust)", cheese: "\(cheese)", meat: "\(meat)", veggie: "\(veggie)"))
                                }
                            }
                        }
                    }
                }
            }
        }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let row = indexPath.row
        cell.textLabel?.text = "\(pizzaList[row].pSize)\n\t\(pizzaList[row].crust)\n\t\(pizzaList[row].cheese)\n\t\(pizzaList[row].meat)\n\t\(pizzaList[row].veggie)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            var fetchedResults = retrievePizza()
            //delete from core data
            context.delete(fetchedResults[indexPath.row])
                do {
                  try context.save()
                  tableView.reloadData()
                } catch let error as NSError {
                  print("Could not save. \(error), \(error.userInfo)")
                }
            //delete from current pizzaList adnd view
            pizzaList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }
    
    //add pizza function that appends new pizza to the array to display on table view
    func addPizza (newPizza: EatPizza) {
        storePizza(pSize: newPizza.pSize, crust: newPizza.crust, cheese: newPizza.cheese, meat: newPizza.meat, veggie: newPizza.veggie)
        pizzaList.append(newPizza)
        self.tableView.reloadData()//update table with new pizzas after hitting done
    }
    
    //store Pizza object usiing model into coredata
    func storePizza(pSize: String, crust: String, cheese: String, meat: String, veggie: String) {
        let pizza = NSEntityDescription.insertNewObject(forEntityName: "PizzaModel", into: context)
        
        //setting Values according to model atttributes
        pizza.setValue(pSize, forKey: "pSize")
        pizza.setValue(crust, forKey: "crust")
        pizza.setValue(cheese, forKey: "cheese")
        pizza.setValue(meat, forKey: "meat")
        pizza.setValue(veggie, forKey: "veggie")
        
        // commit the changes
        saveContext()
    }
    
    //retrieve Pizza object
    func retrievePizza() -> [NSManagedObject]{
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "PizzaModel")
        var fetchedResults:[NSManagedObject]? = nil
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            // if an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        return(fetchedResults)!
    }
    
    //if need to clear the core data, function can be called
    func clearCoreData() {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "PizzaModel")
        var fetchedResults:[NSManagedObject]
        do {
            try fetchedResults = context.fetch(request) as! [NSManagedObject]
            
            if fetchedResults.count > 0 {
                for result:AnyObject in fetchedResults {
                    context.delete(result as! NSManagedObject)
                }
            }
            saveContext()
        } catch {
            // if an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }
    
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    //override function to segue to createpizzaVC when hitting + button
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "createPizzaSegue", //connect to "TextSegue"
           let pizzaVC = segue.destination as? CreatePizzaVC {
            //redirect stored data to ViewController
            pizzaVC.delegate = self
        }
    }
}
