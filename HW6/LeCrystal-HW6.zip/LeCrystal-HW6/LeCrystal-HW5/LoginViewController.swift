//
// Project: LeCrystal-HW6
// EID: CL44964
// Course: CS329E
//
//  LoginViewController.swift
//  LeCrystal-HW6
//
//  Created by Crystal Le on 10/24/22.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController {
    
    @IBOutlet weak var confirmPassword: UITextField!
    @IBOutlet weak var confirmPasswordLabel: UILabel!
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var userID: UITextField!
    @IBOutlet weak var segCtrl: UISegmentedControl!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBAction func loginPressed(_ sender: Any) {
        if (login.titleLabel!.text! == "Sign In") {
            Auth.auth().signIn(withEmail: userID.text!, password: passwordField.text!) {
                authResult, error in
                if let error = error as NSError? {
                    self.statusLabel.text = "\(error.localizedDescription)"
                }
                else {
                    self.statusLabel.text = "Login Successful"
                }
            }
        }
        else if (login.titleLabel!.text! == "Sign Up") {
            if (passwordField.text! == confirmPassword.text!) {
                Auth.auth().createUser(withEmail: userID.text!, password: passwordField.text!) {
                    authResult, error in
                    if let error = error as NSError? {
                        self.statusLabel.text = "\(error.localizedDescription)"
                    }
                    else {
                        self.confirmPassword.text = nil
                        self.statusLabel.text = "Sign Up Successful"
                    }
                }
            }
            else if (passwordField.text! != confirmPassword.text!) {
                self.statusLabel.text = "Password does not match confirmed password"
            }
        }
    }
    
    @IBAction func segCtrlPressed(_ sender: Any) {
        switch segCtrl.selectedSegmentIndex {
        case 0:
            login.setTitle("Sign In", for: .normal)
            confirmPassword.isHidden = true
            confirmPasswordLabel.isHidden = true
        case 1:
            login.setTitle("Sign Up", for: .normal)
            confirmPassword.isHidden = false
            confirmPasswordLabel.isHidden = false
        default:
            login.setTitle("Sign In", for: .normal)
            confirmPassword.isHidden = true
            confirmPasswordLabel.isHidden = true
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        passwordField.isSecureTextEntry = true
        confirmPassword.isSecureTextEntry = true
        confirmPassword.isHidden = true
        confirmPasswordLabel.isHidden = true
        Auth.auth().addStateDidChangeListener(){ //notices whether there is a change or active log in
            auth, user in
            if user != nil {
                self.performSegue(withIdentifier: "loginNavSegue", sender: self)
                self.userID.text = nil
                self.passwordField.text = nil
            } else {
                self.statusLabel.text = "Status"
            }
        }
    }
}
