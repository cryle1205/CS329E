//
// Project: LeCrystal-HW5
// EID: CL44964
// Course: CS329E
//
//  CreatePizzaVC.swift
//  LeCrystal-HW5
//
//  Created by Crystal Le on 10/12/22.
//

import UIKit

class CreatePizzaVC: UIViewController {
    
    var delegate: UIViewController! //delegate for main VC
    var pizzaResultString = "" //holds string to be displayed into table
    
    //all variables that calls on the pizza class properties
    var currentSize = Pizza().pSize
    var currentCrust = Pizza().crust
    var currentVeggie = Pizza().veggie
    var currentMeat = Pizza().meat
    var currentCheese = Pizza().cheese
    
    @IBAction func selectSize(_ sender: Any) {
        switch sizeButton.selectedSegmentIndex {
        case 0:
            self.currentSize = "small"
        case 1:
            self.currentSize = "medium"
        case 2:
            self.currentSize = "large"
        default:
            self.currentSize = "small" //default pizza is a small
        }
    }
    
    @IBAction func doneClick(_ sender: Any) {
        // check that all ingredients have been chosen if not show an error messsage
        if (currentCrust == nil) {
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: "Please select a crust type:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
        } else if (currentCheese == nil) {
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: "Please select a cheeeze type:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
        } else if (currentMeat == nil) {
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: "Please select a meat:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
        } else if (currentVeggie == nil){
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: "Please select a veggie:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
        } else {
            //if all ingrediens are not nil, display label with the summary of the order
            let result = "one \(currentSize) pizza with:\n\t\(currentCrust!)\n\t\(currentCheese!)\n\t\(currentMeat!)\n\t\(currentVeggie!)"
            pizzaResult.text = result
            
            //store string of chosen order to mainVC
            self.pizzaResultString = "\(currentSize)\n\t\(currentCrust!)\n\t\(currentCheese!)\n\t\(currentMeat!)\n\t\(currentVeggie!)"
            let mainVC = delegate as! PizzaAdder
            mainVC.addPizza(newPizza: self.pizzaResultString)
        }
    }
    
    @IBOutlet weak var pizzaResult: UILabel!
    @IBOutlet weak var sizeButton: UISegmentedControl!
    
    @IBAction func selectCrust(_ sender: UIButton) {
        let controller = UIAlertController(
            title: "Select crust",
            message: "Choose a crust type:",
            preferredStyle: .alert)
        controller.addAction(UIAlertAction(
            title: "Thin crust",
            style: .default,
            handler: {(action) in self.currentCrust = "thin crust"}))
        controller.addAction(UIAlertAction(
            title: "Thick crust",
            style: .default,
            handler: {(action) in self.currentCrust = "thick crust"}))
        present(controller, animated: true)
    }
    
    @IBAction func selectVeggies(_ sender: UIButton) {
        let controller = UIAlertController(
            title: "Select veggie",
            message: "Choose your veggies:",
            preferredStyle: .actionSheet)
        controller.addAction(UIAlertAction(
            title: "Mushroom",
            style: .default,
            handler:{(action) in self.currentVeggie = "mushroom"}))
        controller.addAction(UIAlertAction(
            title: "Onion",
            style: .default,
            handler: {(action) in self.currentVeggie = "onion"}))
        controller.addAction(UIAlertAction(
            title: "Green Olive",
            style: .default,
            handler: {(action) in self.currentVeggie = "green olive"}))
        controller.addAction(UIAlertAction(
            title: "Black Olive",
            style: .default,
            handler: {(action) in self.currentVeggie = "black olive"}))
        controller.addAction(UIAlertAction(
            title: "None",
            style: .default,
            handler: {(action) in self.currentVeggie = "none"}))
        present(controller, animated: true)
    }
    
    @IBAction func selectMeat(_ sender: UIButton) {
        let controller = UIAlertController(
            title: "Select meat",
            message: "Choose one meat:",
            preferredStyle: .actionSheet)
        controller.addAction(UIAlertAction(
            title: "Pepperoni",
            style: .default,
            handler:{(action) in self.currentMeat = "pepperoni"}))
        controller.addAction(UIAlertAction(
            title: "Sausage",
            style: .default,
            handler: {(action) in self.currentMeat = "sausage"}))
        controller.addAction(UIAlertAction(
            title: "Canadian Bacon",
            style: .default,
            handler: {(action) in self.currentMeat = "canadian bacon"}))
        present(controller, animated: true)
    }
    
    @IBAction func selectCheese(_ sender: UIButton) {
        let controller = UIAlertController(
            title: "Select cheese",
            message: "Choose a cheese type:",
            preferredStyle: .actionSheet)
        controller.addAction(UIAlertAction(
            title: "Regular cheese",
            style: .default,
            handler:{(action) in self.currentCheese = "regular cheese"}))
        controller.addAction(UIAlertAction(
            title: "No cheese",
            style: .default,
            handler: {(action) in self.currentCheese = "no cheese"}))
        controller.addAction(UIAlertAction(
            title: "Double cheese",
            style: .default,
            handler: {(action) in self.currentCheese = "double cheese"}))
        present(controller, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pizzaResult.text = ""
    }
}
