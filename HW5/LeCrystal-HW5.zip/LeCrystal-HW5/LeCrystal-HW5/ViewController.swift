//
// Project: LeCrystal-HW5
// EID: CL44964
// Course: CS329E
//
//  ViewController.swift
//  LeCrystal-HW5
//
//  Created by Crystal Le on 10/12/22.
//

import UIKit
//create empty array for pizza list
var pizzaList = [String]()

//pizza class to hold variable properties of a pizza
class Pizza {
    var pSize = "small"
    var crust: String?
    var cheese: String?
    var meat: String?
    var veggie: String?
}

//protocol to add Pizza
protocol PizzaAdder {
    func addPizza(newPizza:String)
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, PizzaAdder {
    
    @IBOutlet weak var tableView: UITableView!
    
    let textCellIdentifier = "textCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.reloadData()//update table with new pizzas after hitting done
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let row = indexPath.row
        cell.textLabel!.text = pizzaList[row]
        return cell
    }
    
    //add pizza function that appends new pizza to the array to display on table view
    func addPizza (newPizza: String) {
        pizzaList.append(newPizza)
    }
    
    //override function to segue to createpizzaVC when hitting + button
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "createPizzaSegue", //connect to "TextSegue"
           let pizzaVC = segue.destination as? CreatePizzaVC {
            //redirect stored data to ViewController
            pizzaVC.delegate = self
        }
    }
}

