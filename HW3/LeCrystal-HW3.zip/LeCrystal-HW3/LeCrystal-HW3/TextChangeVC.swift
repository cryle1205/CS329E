//
// Project: LeCrystal-HW3
// EID: CL44964
// Course: CS29E
//
//  TextChangeVC.swift
//  LeCrystal-HW3
//
//  Created by Crystal Le on 9/23/22.
//

import UIKit



class TextChangeVC: UIViewController{
    
    //connecting text field from storyboard
    @IBOutlet weak var textField: UITextField!
    
    //instantiate empty string for new text
    var vc2NewText = ""
    //initiate delegate to redirect back to ViewController
    var delegate: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //display on text field whatever is in the field and the new edited text
        textField.text = vc2NewText
        // Do any additional setup after loading the view.
    }
    
    //action function to save the text that was inputted
    @IBAction func textSaveButton(_ sender: Any) {
        let otherVC = delegate as! TextChanger
        otherVC.changeText(newText: textField.text!)
        self.dismiss(animated: true)
       
    }
    
    
    

}
