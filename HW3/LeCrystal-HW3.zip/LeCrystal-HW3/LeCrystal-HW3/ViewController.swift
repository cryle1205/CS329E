//
// Project: LeCrystal-HW3
// EID: CL44964
// Course: CS29E
//
//  ViewController.swift
//  LeCrystal-HW3
//
//  Created by Crystal Le on 9/23/22.
//

import UIKit

//protocols for textchanger and colorchanger
protocol TextChanger{
    func changeText(newText:String)
}

protocol ColorChanger{
    func changeColor(newColor:UIColor)
}

class ViewController: UIViewController, TextChanger, ColorChanger{
    
    //connecting label from the storyboard
    @IBOutlet weak var currentTextDisplay: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //dummy string that is displayed initially
        currentTextDisplay.text = "Text goes here"
        
    }
    
    //assigned function callers of the protocols to set new text/color
    func changeText(newText: String) {
        currentTextDisplay.text = newText
    }
    func changeColor(newColor: UIColor) {
        currentTextDisplay.backgroundColor = newColor
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "TextSegue", //connect to "TextSegue"
           let nextVC = segue.destination as? TextChangeVC{
            //set new text display to the inputted text
            nextVC.vc2NewText = currentTextDisplay.text!
            //redirect stored data to ViewController
            nextVC.delegate = self
        }
        if segue.identifier == "ColorSegue", //connect to "ColorSegue"
           let nextVC2 = segue.destination as? ColorChangeVC{
            //redirect stored data to ViewController
            nextVC2.delegate2 = self
        }
    }
}
