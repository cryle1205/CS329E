//
// Project: LeCrystal-HW3
// EID: CL44964
// Course: CS29E
//
//  ColorChangeVC.swift
//  LeCrystal-HW3
//
//  Created by Crystal Le on 9/23/22.
//

import UIKit

class ColorChangeVC: UIViewController {
    
    //initiate delegate to redirect back to ViewController
    var delegate2: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //Red button action function
    @IBAction func RedButton(_ sender: Any) {
        let otherVC2 = delegate2 as! ColorChanger
        //set background of text to red
        otherVC2.changeColor(newColor: UIColor.red)
        self.dismiss(animated: true)
    }
    //Blue button action function
    @IBAction func BlueButton(_ sender: Any) {
        let otherVC2 = delegate2 as! ColorChanger
        //set background of text to blue
        otherVC2.changeColor(newColor: UIColor.blue)
        self.dismiss(animated: true)
    }
}
    

