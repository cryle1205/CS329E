//
// Filename: LeCrystal-HW10
// EID: CL44964
// Course: CS329E
//
//  MyCollectionViewCell.swift
//  LeCrystal-HW10
//
//  Created by Crystal Le on 11/26/22.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myImage: UIImageView!
    
}
