//
//  DetailViewController.swift
//  LeCrystal-HW10
//
// Filename: LeCrystal-HW10
// EID: CL44964
// Course: CS329E
//
//  Created by Crystal Le on 11/27/22.
//

import UIKit

class DetailViewController: UIViewController {

    var seeImage:UIImage = UIImage()
    
    @IBOutlet weak var imageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView.contentMode = .scaleAspectFit
        imageView.image = seeImage
        
    }
}
