// Project: LeCrystal-HW9
// EID: CL44964
// Course: CS329E
//  ViewController.swift
//  LeCrystal-HW9
//
//  Created by Crystal Le on 11/14/22.
//

import UIKit

class ViewController: UIViewController {
    
    //initialize all variables that will be used
    var viewBox: UIView!
    var timer = Timer()
    var currentPos: (x:Int, y:Int) = (0,0)
    let colorRed = UIColor.red
    let colorGreen = UIColor.green
    var widthUnit: CGFloat = 0
    var heightUnit: CGFloat = 0
    var screenAreaHeight: CGFloat = 0
    var midX: CGFloat = 0
    var midY: CGFloat = 0
    var upFlag: Bool = false
    var downFlag: Bool = false
    var leftFlag: Bool = false
    var rightFlag: Bool = false
    
    override func viewDidLoad(){
        super.viewDidLoad()
        //width of unit on imaginary viewBox grid
        widthUnit = self.view.frame.width * (1/9)
        heightUnit = (763/19)
        
        screenAreaHeight = 763 //safe Area Height found via StackOverflow thread
        midX = self.view.frame.midX
        midY = screenAreaHeight / 2
        
        //Add ViewBox programatically
        viewBox = UIView(frame: CGRect(x: 0, y: 0, width: widthUnit, height: heightUnit))
        currentPos = (5,10)
        viewBox.center = CGPoint(x: midX, y: midY)
        viewBox.backgroundColor = colorGreen
        view.addSubview(viewBox)
        
        //Add all Gestures to the viewBox programatically
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(recognizeTapGesture(recognizer:)))
        self.view.addGestureRecognizer(tapGesture)
        
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(recognizeLeftSwipe(recognizer:)))
        leftSwipe.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(leftSwipe)
        
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(recognizeRightSwipe(recognizer:)))
        rightSwipe.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(rightSwipe)
        
        let upSwipe = UISwipeGestureRecognizer(target: self, action: #selector(recognizeUpSwipe(recognizer:)))
        upSwipe.direction = UISwipeGestureRecognizer.Direction.up
        self.view.addGestureRecognizer(upSwipe)
        
        let downSwipe = UISwipeGestureRecognizer(target: self, action: #selector(recognizeDownSwipe(recognizer:)))
        downSwipe.direction = UISwipeGestureRecognizer.Direction.down
        self.view.addGestureRecognizer(downSwipe)
    }
    
        
    @IBAction func recognizeTapGesture(recognizer: UITapGestureRecognizer){
        //flags to ensure which is activated and deactivate past Gesture
        rightFlag = false
        leftFlag = false
        upFlag = false
        downFlag = false
        viewBox.backgroundColor = colorGreen
        currentPos = (5,10)
        viewBox.center.x = view.center.x
        viewBox.center.y = view.center.y

        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            self.viewBox.center.y += (763/19)
            self.currentPos.y += 1
            if self.currentPos.y == 19 {
                self.timer.invalidate()
                self.viewBox.backgroundColor = self.colorRed
            }
        })
    }
    
    @IBAction func recognizeRightSwipe(recognizer: UISwipeGestureRecognizer){
        //flags to ensure which is activated and deactivate past Gesture
        rightFlag = true
        leftFlag = false
        upFlag = false
        downFlag = false
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            if self.viewBox.backgroundColor == self.colorGreen && self.rightFlag == true {
                self.viewBox.center.x += self.widthUnit
                self.currentPos.x += 1
                if self.currentPos.x == 9 {
                    self.timer.invalidate()
                    self.viewBox.backgroundColor = self.colorRed
                }
            }
        })
    }
    
    @IBAction func recognizeLeftSwipe(recognizer: UISwipeGestureRecognizer){
        //flags to ensure which is activated and deactivate past Gesture
        rightFlag = false
        leftFlag = true
        upFlag = false
        downFlag = false
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            if self.viewBox.backgroundColor == self.colorGreen && self.leftFlag == true {
                self.viewBox.center.x -= self.widthUnit
                print("Before left position \(self.currentPos)")
                self.currentPos.x -= 1
                print("Before After left position \(self.currentPos)")
                if self.currentPos.x == 1{
                    self.timer.invalidate()
                    self.viewBox.backgroundColor = self.colorRed
                }
            }
        })
    }
    
    @IBAction func recognizeUpSwipe(recognizer: UISwipeGestureRecognizer){
        //flags to ensure which is activated and deactivate past Gesture
        rightFlag = false
        leftFlag = false
        upFlag = true
        downFlag = false
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            if self.viewBox.backgroundColor == self.colorGreen && self.upFlag == true {
                self.viewBox.center.y -= (773/19)
                print("Before up position \(self.currentPos)")
                self.currentPos.y -= 1
                print("After up position \(self.currentPos)")
                if self.currentPos.y == 3 {
                    self.timer.invalidate()
                    self.viewBox.backgroundColor = self.colorRed
                }
            }
        })
    }
    
    @IBAction func recognizeDownSwipe(recognizer: UISwipeGestureRecognizer){
        //flags to ensure which is activated and deactivate past Gesture
        rightFlag = false
        leftFlag = false
        upFlag = false
        downFlag = true
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            if self.viewBox.backgroundColor == self.colorGreen && self.downFlag == true {
                self.viewBox.center.y += (763/19)
                print("Before down position \(self.currentPos)")
                self.currentPos.y += 1
                print("After down position \(self.currentPos)")
                if self.currentPos.y == 20 {
                    self.timer.invalidate()
                    self.viewBox.backgroundColor = self.colorRed
                }
            }
        })
    }
}
