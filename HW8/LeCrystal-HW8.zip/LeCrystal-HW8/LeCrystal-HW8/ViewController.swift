// Project: LeCrystal-HW8
// EID: CL44964
// Course: CS329E
//
//  ViewController.swift
//  LeCrystal-HW8
//
//  Created by Crystal Le on 11/6/22.
//

import UIKit
import UserNotifications

//global variable of count
var count = 0

class ViewController: UIViewController {

    @IBOutlet weak var towerImage: UIButton!
    @IBOutlet weak var utImage: UIButton!
    
    @IBAction func towerPressed(_ sender: Any) {
        if (self.towerImage.alpha == 1.0) {
            //animate if current tower is showing
            UIView.animate(
                withDuration: 1.0,
                delay: 0.0,
                options: .curveEaseOut,
                animations: {
                    self.towerImage.alpha = 0.0
                },
                completion: { finished in
                    print("Tower Pressed! count: \(count)")
                    //if pressed then fade out to UT image
                    UIView.animate(
                        withDuration: 1.0,
                        delay: 0.0,
                        options: .curveEaseIn,
                        animations: {
                            self.utImage.alpha = 1.0
                        },
                        completion: nil
                    )
                })
            count += 1 //add to global count
            //if count == 4, then notification should be triggered after 8 sec
            if (count % 4 == 0){
                
                let content = UNMutableNotificationContent()
                content.title = "Click Count"
                content.subtitle = "Why ya clicking so much?"
                content.body = "You have clicked \(count) times"
                //content.sound = UNNotificationSound.default
                
                //create trigger
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 8, repeats: false)
                
                //combine itt all into a request
                let request = UNNotificationRequest(identifier: "myNotification", content: content, trigger: trigger)
                
                UNUserNotificationCenter.current().add(request)
            }
        } else if (self.utImage.alpha == 1.0) {
            //if UT image is currently displaying, fade out once pressed
            UIView.animate(
                withDuration: 1.0,
                delay: 0.0,
                options: .curveEaseOut,
                animations: {
                    self.utImage.alpha = 0.0
                },
                completion: { finished in
                    print("UT Pressed! count: \(count)")
                    //fade in tower image again
                    UIView.animate(
                        withDuration: 1.0,
                        delay: 0.0,
                        options: .curveEaseIn,
                        animations: {
                            self.towerImage.alpha = 1.0
                        },
                        completion: nil
                    )
                })
            count += 1 //add to global variable count
            if (count % 4 == 0){
                
                let content = UNMutableNotificationContent()
                content.title = "Click Count"
                content.subtitle = "Why ya clicking so much?"
                content.body = "You have clicked \(count) times"
                //content.sound = UNNotificationSound.default
                
                //create trigger
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 8, repeats: false)
                
                //combine it all into a request
                let request = UNNotificationRequest(identifier: "myNotification", content: content, trigger: trigger)
                
                UNUserNotificationCenter.current().add(request)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.utImage.alpha = 0.0
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) {
            granted, error in
            if granted {
                print("All set!")
            }
            else if let error = error {
                print(error.localizedDescription)
            }
        }
    }
}

