//  Project: LeCrystal-HW4
//  EID: cl44964
//  Course: CS329E
//
//  CalculateViewController.swift
//  LeCrystal-HW4
//
//  Created by Crystal Le on 10/3/22.
//

import UIKit

class CalculateViewController: UIViewController {
    
    var currentOperator = ""
    var delegate: UIViewController!
    
    @IBOutlet weak var operand1: UITextField!
    @IBOutlet weak var operand2: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var operatorLabel: UILabel!
    
   
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        operatorLabel.text = currentOperator
    }
    
    @IBAction func calculateButton(_ sender: Any) {
        
        if operand1.text!.contains(".") || operand2.text!.contains(".") {
            let newOperand1 = Float(operand1.text!)
            let newOperand2 = Float(operand2.text!)
            if currentOperator == "+"{
                resultLabel.text = String(newOperand1! + newOperand2!)
            }
            else if currentOperator == "-" {
                resultLabel.text = String(newOperand1! - newOperand2!)
            }
            else if currentOperator == "*" {
                resultLabel.text = String(newOperand1! * newOperand2!)
            }
            else if currentOperator == "/" {
                resultLabel.text = String(newOperand1! / newOperand2!)
            }
        }
        else {
            let newOperand1 = Int(operand1.text!)
            let newOperand2 = Int(operand2.text!)
            if currentOperator == "+"{
                resultLabel.text = String(newOperand1! + newOperand2!)
            }
            else if currentOperator == "-" {
                resultLabel.text = String(newOperand1! - newOperand2!)
            }
            else if currentOperator == "*" {
                resultLabel.text = String(newOperand1! * newOperand2!)
            }
            else if currentOperator == "/" {
                if newOperand1! < newOperand2! {
                    resultLabel.text = String(Float(newOperand1!)/Float(newOperand2!))
                }
                else {
                    resultLabel.text = String(newOperand1!/newOperand2!)
                }
            }
        }
    }
}
