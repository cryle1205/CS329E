//  Project: LeCrystal-HW4
//  EID: cl44964
//  Course: CS329E
//
//  ViewController.swift
//  LeCrystal-HW4
//
//  Created by Crystal Le on 10/3/22.
//

import UIKit

public let operators = ["Add", "Subtract", "Multiply", "Divide"]
public let operatorSymbols = ["+", "-", "*", "/"]

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var tableView: UITableView!
    
    let textCellIndentifier = "TextCell"
    let calculateSegue = "calculateSegue"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return operators.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIndentifier, for: indexPath)
        cell.textLabel?.text = operators[row]
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == calculateSegue,
           let destination = segue.destination as? CalculateViewController, let operatorIndex = tableView.indexPathForSelectedRow?.row {
            destination.currentOperator = operatorSymbols[operatorIndex]
        }
    }
}

