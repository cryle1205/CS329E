//
//  UserQRViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 11/3/22.
//
import UIKit

class UserQRViewController: UIViewController {
    
    @IBOutlet weak var QRImage: UIImageView!
    
    
    // used to generate the QR code with the user UID as the information
    func generateQRCode(from input: String) -> UIImage? {
        let qrInfo = input.data(using: String.Encoding.isoLatin1)
        if let QRFilter = CIFilter(name: "CIQRCodeGenerator") {
            QRFilter.setValue(qrInfo, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 20, y: 20)
            
            guard let QRImage = QRFilter.outputImage?.transformed(by: transform) else {return nil}
            
            // return the qr code image
            return UIImage(ciImage: QRImage)
        }
        return nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // call on generateQRCode function to create QR code
        let imager = generateQRCode(from: coreUserID)
        
        // set image equal to the QR code
        QRImage.image = imager
    }
    
    // used to add darkmode to the view controller
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
    }
}
