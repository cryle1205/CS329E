//
//  TableProfileViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 12/1/22.
//
import UIKit

class TableProfileViewController: UIViewController {
    
    var tableUserID = ""
    
    // create outlets for imageview and labels
    @IBOutlet weak var friendImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var classificationLabel: UILabel!
    @IBOutlet weak var majorLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var bioLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bioLabel.sizeToFit()
        
        // make the profile picture a circle
        friendImage.layer.borderWidth = 1.0
        friendImage.layer.masksToBounds = false
        friendImage.layer.borderColor = UIColor.white.cgColor
        friendImage.layer.cornerRadius = friendImage.layer.frame.size.width / 2
        friendImage.clipsToBounds = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // add darkmode to the settings
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
        
        // create a reference to the friend's document with their UID
        let ref = db.collection("Users").document("\(tableUserID)")
        
        // retrieve the information from the document
        ref.getDocument { (document, error) in
            if let document = document, document.exists {
                let first = document.get("first") as! String
                let last = document.get("last") as! String
                let classification = document.get("classification") as! String
                let major = document.get("major") as! String
                let otherInfo = document.get("otherInfo") as! String
                let email = document.get("email") as! String
                let pNumber = document.get("pNumber") as! String
                let imageURL = document.get("imageURL") as! String
                self.majorLabel.text! = major
                self.classificationLabel.text! = classification
                self.nameLabel.text! = "\(first) \(last)"
                self.phoneLabel.text! = pNumber
                self.emailLabel.text! = email
                self.bioLabel.text! = otherInfo
                
                let url = URL(string: imageURL)!
                let session = URLSession(configuration: .default)
                
                // Create a task for accessing the image
                let task = session.dataTask(with: url) {
                    (data, response, error) in

                    guard error == nil else { return }

                    if let httpResponse = response as? HTTPURLResponse {

                        // ensure that we got a response code of 200 (which means "success")
                        guard httpResponse.statusCode == 200 else { return }

                        if let receivedData = data {
                            DispatchQueue.main.async {
                                
                                // set the friend's profile image equal to the image found on firestore
                                self.friendImage.image = UIImage(data: receivedData)
                            }
                        }
                    }
                }
                task.resume()
            }
            else {
                print("Document does not exist")
            }
        }
    }
}
