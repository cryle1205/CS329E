//
//  RegisterViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 10/13/22.
//
import UIKit
import FirebaseAuth
import Firebase
import CoreData
import FirebaseFirestore
import FirebaseStorage

var registerClass: String = ""

// create a reference to firestore
let db = Firestore.firestore()

// create a reference to firebase storage
let storage = Storage.storage().reference()
var urlImage:String = ""

class RegisterViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    
    var registerDelegate: UIViewController!
    
    // create an image picker
    let picker = UIImagePickerController()
    
    // create outlets for textfields, labels, buttons, and imageviews
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var firstNameField: UITextField!
    @IBOutlet weak var lastNameField: UITextField!
    @IBOutlet weak var classificationMenu: UIButton!
    @IBOutlet weak var majorMenu: UIButton!
    @IBOutlet weak var phoneNumberField: UITextField!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var confirmPasswordField: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
        firstNameField.delegate = self
        lastNameField.delegate = self
        phoneNumberField.delegate = self
        usernameField.delegate = self
        passwordField.delegate = self
        confirmPasswordField.delegate = self
        statusLabel.text = ""
        
        // make the following passwords secure entry
        passwordField.isSecureTextEntry = true
        confirmPasswordField.isSecureTextEntry = true
        
        // function call to create the menus for classification and major
        chooseClassification()
        chooseMajor()
        
        // makes the imageview a circle
        profileImageView.layer.borderWidth = 1.0
        profileImageView.layer.masksToBounds = false
        profileImageView.layer.borderColor = UIColor.white.cgColor
        profileImageView.layer.cornerRadius = profileImageView.layer.frame.size.width / 2
        profileImageView.clipsToBounds = true
    }
    
    // adds darkmode setting to this view controller
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
    }
    
    @IBAction func signupPressed(_ sender: Any) {
        
        // checks if password is the same as the confirmed password
        if (passwordField.text! == confirmPasswordField.text!) {
            
            // creates a user based on the information given in the textfields
            Auth.auth().createUser(withEmail: usernameField.text!, password: passwordField.text!) {
                authResult, error in
                if let error = error as NSError? {
                    
                    // if an error occurs then print the error description in the status label
                    self.statusLabel.text = "\(error.localizedDescription)"
                }
                else {
                    
                    // if successful then print login successful
                    self.passwordField.text = nil
                    self.confirmPasswordField.text = nil
                    self.statusLabel.text = "Sign-Up Successful"
                
                    // get image data of the current profile image
                    guard let imageData = self.profileImageView.image?.pngData() else {
                        return
                    }
                    
                    // store the data into firebase storage
                    storage.child("Users").child("\(Auth.auth().currentUser!.uid).png").putData(imageData, metadata: nil, completion: { _, error in
                        guard error == nil else {
                            print("Failed to upload")
                            return
                        }
                        
                        // download the corresponding url of the image
                        storage.child("Users").child("\(Auth.auth().currentUser!.uid).png").downloadURL(completion: { url, error in
                            guard let url = url, error == nil else {
                                return
                            }
                            
                            // create a variable equal to the image url
                            let urlString = url.absoluteString
                            
                            // save all the inserted information including the image url into firestore into a document named the user UID
                            db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData([
                                "userID": Auth.auth().currentUser!.uid,
                                "first": self.firstNameField.text!,
                                "last": self.lastNameField.text!,
                                "classification": self.classificationMenu.currentTitle!,
                                "major": self.majorMenu.currentTitle!,
                                "pNumber": self.phoneNumberField.text!,
                                "email": self.usernameField.text!,
                                "otherInfo": "",
                                "friends": [],
                                "imageURL": urlString
                            ]) { err in
                                if let err = err {
                                    print("Error adding document: \(err)")
                                } else {
                                    print("Successful adding document!!!")
                                }
                            }
                        })
                    })
                    
                    // store the current user UID into core data
                    self.storeUserID(userID: Auth.auth().currentUser!.uid)
                    
                    // perform segue to the loading screen
                    self.performSegue(withIdentifier: "registerLoadingScreenSegue", sender: self)
                }
            }
        }
        
        // if the password is not the same as the confirmed password then print that it does not match
        else if (passwordField.text! != confirmPasswordField.text!) {
            self.statusLabel.text = "Password does not match confirmed password"
        }
    }
    
    // function to give the classification menu options
    func chooseClassification() {
        
        // list of classifications
        let classList = ["Freshman", "Sophomore", "Junior", "Senior"]
        
        var childrenList:[UIAction] = []
        
        // append the list of classifications to the classification menu
        for i in classList {
            childrenList.append(UIAction(title: i, state: .on, handler:
                                            {(action: UIAction) in
                
                // once an option is selected, change the appearance of the menu
                self.classificationMenu.configuration = .filled()
                self.classificationMenu.configuration?.baseBackgroundColor = utOrange
                self.classificationMenu.configuration?.baseForegroundColor = .black
                                               }))
        }
        
        // create the menu based on the information above
           classificationMenu.menu = UIMenu(children: childrenList)
           classificationMenu.showsMenuAsPrimaryAction = true
           classificationMenu.changesSelectionAsPrimaryAction = true
    }
    
    // function to give the major menu options
    func chooseMajor() {
        
        // list of majors
        let majorList = ["ACCOUNTING", "ACTUARIAL SCIENCE", "ADVERTISING AND PUBLIC RELATIONS", "AEROSPACE ENGINEERING", "AGRICULTURAL ECONOMICS", "AGRICULTURE PRODUCTION AND MANAGEMENT", "ANIMAL SCIENCES", "ANTHROPOLOGY AND ARCHEOLOGY", "APPLIED MATHEMATICS", "ARCHITECTURAL ENGINEERING", "ARCHITECTURE", "AREA ETHNIC AND CIVILIZATION STUDIES", "ART AND MUSIC EDUCATION", "ART HISTORY AND CRITICISM", "ASTRONOMY AND ASTROPHYSICS", "ATMOSPHERIC SCIENCES AND METEOROLOGY", "BIOCHEMICAL SCIENCES", "BIOLOGICAL ENGINEERING", "BIOLOGY", "BIOMEDICAL ENGINEERING", "BOTANY", "BUSINESS ECONOMICS", "BUSINESS MANAGEMENT AND ADMINISTRATION", "CHEMICAL ENGINEERING", "CHEMISTRY", "CIVIL ENGINEERING", "CLINICAL PSYCHOLOGY", "COGNITIVE SCIENCE AND BIOPSYCHOLOGY", "COMMERCIAL ART AND GRAPHIC DESIGN", "COMMUNICATION DISORDERS SCIENCES AND SERVICES", "COMMUNICATION TECHNOLOGIES", "COMMUNICATIONS", "COMMUNITY AND PUBLIC HEALTH", "COMPOSITION AND RHETORIC", "COMPUTER ADMINISTRATION MANAGEMENT AND SECURITY", "COMPUTER AND INFORMATION SYSTEMS", "COMPUTER ENGINEERING", "COMPUTER NETWORKING AND TELECOMMUNICATIONS", "COMPUTER PROGRAMMING AND DATA PROCESSING", "COMPUTER SCIENCE", "CONSTRUCTION SERVICES", "COSMETOLOGY SERVICES AND CULINARY ARTS", "COUNSELING PSYCHOLOGY", "COURT REPORTING", "CRIMINAL JUSTICE AND FIRE PROTECTION", "CRIMINOLOGY", "DRAMA AND THEATER ARTS", "EARLY CHILDHOOD EDUCATION", "ECOLOGY", "ECONOMICS", "EDUCATIONAL ADMINISTRATION AND SUPERVISION", "EDUCATIONAL PSYCHOLOGY", "ELECTRICAL ENGINEERING", "ELECTRICAL ENGINEERING TECHNOLOGY", "ELECTRICAL, MECHANICAL, AND PRECISION TECHNOLOGIES AND PRODUCTION", "ELEMENTARY EDUCATION", "ENGINEERING AND INDUSTRIAL MANAGEMENT", "ENGINEERING MECHANICS PHYSICS AND SCIENCE", "ENGINEERING TECHNOLOGIES", "ENGLISH LANGUAGE AND LITERATURE", "ENVIRONMENTAL ENGINEERING", "ENVIRONMENTAL SCIENCE", "FAMILY AND CONSUMER SCIENCES", "FILM VIDEO AND PHOTOGRAPHIC ARTS", "FINANCE", "FINE ARTS", "FOOD SCIENCE", "FORESTRY", "FRENCH GERMAN LATIN AND OTHER COMMON FOREIGN LANGUAGE STUDIES", "GENERAL AGRICULTURE", "GENERAL BUSINESS", "GENERAL EDUCATION", "GENERAL ENGINEERING", "GENERAL MEDICAL AND HEALTH SERVICES", "GENERAL SOCIAL SCIENCES", "GENETICS", "GEOGRAPHY", "GEOLOGICAL AND GEOPHYSICAL ENGINEERING", "GEOLOGY AND EARTH SCIENCE", "GEOSCIENCES", "HEALTH AND MEDICAL ADMINISTRATIVE SERVICES", "HEALTH AND MEDICAL PREPARATORY PROGRAMS", "HISTORY", "HOSPITALITY MANAGEMENT", "HUMAN RESOURCES AND PERSONNEL MANAGEMENT", "HUMAN SERVICES AND COMMUNITY ORGANIZATION", "HUMANITIES", "INDUSTRIAL AND MANUFACTURING ENGINEERING", "INDUSTRIAL AND ORGANIZATIONAL PSYCHOLOGY", "INDUSTRIAL PRODUCTION TECHNOLOGIES", "INFORMATION SCIENCES", "INTERCULTURAL AND INTERNATIONAL STUDIES", "INTERDISCIPLINARY SOCIAL SCIENCES", "INTERNATIONAL BUSINESS", "INTERNATIONAL RELATIONS", "JOURNALISM", "LANGUAGE AND DRAMA EDUCATION", "LIBERAL ARTS", "LIBRARY SCIENCE", "LINGUISTICS AND COMPARATIVE LANGUAGE AND LITERATURE", "MANAGEMENT INFORMATION SYSTEMS AND STATISTICS", "MARKETING AND MARKETING RESEARCH", "MASS MEDIA", "MATERIALS ENGINEERING AND MATERIALS SCIENCE", "MATERIALS SCIENCE", "MATHEMATICS", "MATHEMATICS AND COMPUTER SCIENCE", "MATHEMATICS TEACHER EDUCATION", "MECHANICAL ENGINEERING", "MECHANICAL ENGINEERING RELATED TECHNOLOGIES", "MEDICAL ASSISTING SERVICES", "MEDICAL TECHNOLOGIES TECHNICIANS", "METALLURGICAL ENGINEERING", "MICROBIOLOGY", "MILITARY TECHNOLOGIES", "MINING AND MINERAL ENGINEERING", "MISCELLANEOUS AGRICULTURE", "MISCELLANEOUS BIOLOGY", "MISCELLANEOUS BUSINESS & MEDICAL ADMINISTRATION", "MISCELLANEOUS EDUCATION", "MISCELLANEOUS ENGINEERING", "MISCELLANEOUS ENGINEERING TECHNOLOGIES", "MISCELLANEOUS FINE ARTS", "MISCELLANEOUS HEALTH MEDICAL PROFESSIONS", "MISCELLANEOUS PSYCHOLOGY", "MISCELLANEOUS SOCIAL SCIENCES", "MOLECULAR BIOLOGY", "MULTI-DISCIPLINARY OR GENERAL SCIENCE", "MULTI/INTERDISCIPLINARY STUDIES", "MUSIC", "N/A (less than bachelor's degree)", "NATURAL RESOURCES MANAGEMENT", "NAVAL ARCHITECTURE AND MARINE ENGINEERING", "NEUROSCIENCE", "NUCLEAR ENGINEERING", "NUCLEAR, INDUSTRIAL RADIOLOGY, AND BIOLOGICAL TECHNOLOGIES", "NURSING", "NUTRITION SCIENCES", "OCEANOGRAPHY", "OPERATIONS LOGISTICS AND E-COMMERCE", "OTHER FOREIGN LANGUAGES", "PETROLEUM ENGINEERING", "PHARMACOLOGY", "PHARMACY PHARMACEUTICAL SCIENCES AND ADMINISTRATION", "PHILOSOPHY AND RELIGIOUS STUDIES", "PHYSICAL AND HEALTH EDUCATION TEACHING", "PHYSICAL FITNESS PARKS RECREATION AND LEISURE", "PHYSICAL SCIENCES", "PHYSICS", "PHYSIOLOGY", "PLANT SCIENCE AND AGRONOMY", "POLITICAL SCIENCE AND GOVERNMENT", "PRE-LAW AND LEGAL STUDIES", "PSYCHOLOGY", "PUBLIC ADMINISTRATION", "PUBLIC POLICY", "SCHOOL STUDENT COUNSELING", "SCIENCE AND COMPUTER TEACHER EDUCATION", "SECONDARY TEACHER EDUCATION", "SOCIAL PSYCHOLOGY", "SOCIAL SCIENCE OR HISTORY TEACHER EDUCATION", "SOCIAL WORK", "SOCIOLOGY", "SOIL SCIENCE", "SPECIAL NEEDS EDUCATION", "STATISTICS AND DECISION SCIENCE", "STUDIO ARTS", "TEACHER EDUCATION: MULTIPLE LEVELS", "THEOLOGY AND RELIGIOUS VOCATIONS", "TRANSPORTATION SCIENCES AND TECHNOLOGIES", "TREATMENT THERAPY PROFESSIONS", "UNITED STATES HISTORY", "VISUAL AND PERFORMING ARTS", "ZOOLOGY"]
        
        var childrenList:[UIAction] = []
        
        // append the list of majors to the majors menu
        for i in majorList {
            childrenList.append(UIAction(title: i, state: .on, handler:
                                            {(action: UIAction) in
                
                // once an option is selected, change the appearance of the menu
                self.majorMenu.configuration = .filled()
                self.majorMenu.configuration?.baseBackgroundColor = utOrange
                self.majorMenu.configuration?.baseForegroundColor = .black
                                               }))
        }
        
        // create the menu based on the information above
           majorMenu.menu = UIMenu(children: childrenList)
            majorMenu.showsMenuAsPrimaryAction = true
            majorMenu.changesSelectionAsPrimaryAction = true
    }
    
    @IBAction func changePhotoButtonPressed(_ sender: Any) {
        
        // define settings of image picker and present
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        // create a variable equal to the image the user chose
        let chosenImage = info[.originalImage] as! UIImage

        // set the profile image on the register view controller equal to the chosen image
        profileImageView.image = chosenImage
        
        // change the content mode of the image to maintain the shape
        profileImageView.contentMode = .scaleAspectFill
        
        dismiss(animated: true)
    }
    
    // once an image is chosen, the image picker will disappear
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }
    
    // used to store the current user UID into core data
    func storeUserID(userID: String) {
        
        let user = NSEntityDescription.insertNewObject(forEntityName: "User", into: context)
        
        user.setValue(userID, forKey: "coreUserID")
        saveContext()
    }
    
    // save the information into core data
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    // Called when 'return' key pressed
    func textFieldShouldReturn(_ textField:UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user clicks on the view outside of the UITextField
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
