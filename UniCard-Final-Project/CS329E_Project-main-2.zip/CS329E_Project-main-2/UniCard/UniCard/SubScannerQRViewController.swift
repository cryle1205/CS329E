//
//  SubScannerQRViewController.swift
//  QRCodeScannerTrial
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 11/3/22.
//
import UIKit
import AVFoundation

class SubScannerQRViewController: UIViewController {
    
    // create capture session, video preview layer, and view
    var captureSession = AVCaptureSession()
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    var qrCodeFrameView: UIView?
    var friendCoreUserID: String = ""
    
    // create a list of supported code types
    private let supportedCodeTypes = [AVMetadataObject.ObjectType.upce,
                                      AVMetadataObject.ObjectType.code39,
                                      AVMetadataObject.ObjectType.code39Mod43,
                                      AVMetadataObject.ObjectType.code93,
                                      AVMetadataObject.ObjectType.code128,
                                      AVMetadataObject.ObjectType.ean8,
                                      AVMetadataObject.ObjectType.ean13,
                                      AVMetadataObject.ObjectType.aztec,
                                      AVMetadataObject.ObjectType.pdf417,
                                      AVMetadataObject.ObjectType.itf14,
                                      AVMetadataObject.ObjectType.dataMatrix,
                                      AVMetadataObject.ObjectType.interleaved2of5,
                                      AVMetadataObject.ObjectType.qr]

    // create outlets for the view and label
    @IBOutlet weak var topBar: UIView!
    @IBOutlet weak var messageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Get the back-facing camera for capturing videos
        guard let captureDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Failed to get the camera device")
            return
        }
        
        do {
            // Get an instance of the AVCaptureDeviceInput class using the previous device object
            let input = try AVCaptureDeviceInput(device: captureDevice)
            
            // Set the input device on the capture session
            captureSession.addInput(input)
            
            // Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession.addOutput(captureMetadataOutput)
            
            // Set delegate and use the default dispatch queue to execute the call back
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            
            //captureMetadataOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
            captureMetadataOutput.metadataObjectTypes = supportedCodeTypes
            
            // Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer?.videoGravity = AVLayerVideoGravity.resizeAspectFill
            videoPreviewLayer?.frame = view.layer.bounds
            view.layer.addSublayer(videoPreviewLayer!)
            
            let backgroundQueue = DispatchQueue(label: "backgroundQueue", qos: .background)
            
            // Start video capture
            backgroundQueue.async {
                self.captureSession.startRunning()
            }
            
            // Move the message label and top bar to the front
            view.bringSubviewToFront(topBar)
            view.bringSubviewToFront(messageLabel)
            
            // Initialize QR Code Frame to highlight the QR Code
            qrCodeFrameView = UIView()
            
            if let qrcodeFrameView = qrCodeFrameView {
                qrcodeFrameView.layer.borderColor = UIColor.yellow.cgColor
                qrcodeFrameView.layer.borderWidth = 2
                view.addSubview(qrcodeFrameView)
                view.bringSubviewToFront(qrcodeFrameView)
            }
            
        } catch {
            // If any error occurs, simply print it out and don't continue anymore
            print(error)
            return
        }
    }
    
    // used to add darkmode setting to view controller
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
    }
}

extension SubScannerQRViewController: AVCaptureMetadataOutputObjectsDelegate {
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        
        // Check if the metadataObjects array is not nil and it contains at least one object
        if metadataObjects.count == 0 {
            qrCodeFrameView?.frame = CGRect.zero
            messageLabel.text = "No QR code detected"
            return
        }
        
        // Get the metadata object
        let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        
        if supportedCodeTypes.contains(metadataObj.type) {
            
            // If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
            let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj)
            qrCodeFrameView?.frame = barCodeObject!.bounds
            
            if metadataObj.stringValue != nil {
                captureSession.stopRunning()
                
                // create a reference to the corresponding firestore user document
                let ref = db.collection("Users").document("\(coreUserID)")
                    
                // retrieve the information from the document
                ref.getDocument { (document, error) in
                    if let document = document, document.exists {
                        var friends = document.get("friends") as! Array<String>
                        self.friendCoreUserID = metadataObj.stringValue!
                        if friends.contains(self.friendCoreUserID) {
                            
                            // create an alert that the friend has already been added
                            let controller = UIAlertController(title: "Unable to Add", message: "This friend already exists in your contacts.", preferredStyle: .alert)
                            
                            // add an ok action to the alert
                            controller.addAction(UIAlertAction(title: "Ok", style: .default))
                            self.present(controller, animated: true)
                            
                            // restart capture session after alert has been addressed
                            self.captureSession.startRunning()
                        }
                        else {
                            
                            // if the QR code was successfully scanned
                            self.messageLabel.text = "QR code scanned"
                            
                            // create an alert that allows the user to deny or accept a friend request
                            let controller = UIAlertController(title: "Add Friend", message: "Do you want to accept this friend request?", preferredStyle: .alert)
                            
                            // add a yes action to the alert
                            controller.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action) in
                                friends.append(self.friendCoreUserID)
                                
                                // if yes, then update the list of friends with the friend's UID
                                db.collection("Users").document("\(coreUserID)").setData([ "friends": friends], merge: true)
                                
                                // perform the segue to the profile view controller in tab view
                                self.performSegue(withIdentifier: "subScannerContactsSegue", sender: nil)
                            }))
                            
                            // add a no action to the alert
                            controller.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action) in
                                let otherQueue = DispatchQueue(label: "otherQueue", qos: .background)
                                otherQueue.async {
                                    
                                    // start the capturing session once the alert is addressed
                                    self.captureSession.startRunning()
                                }
                                
                                // tell the user that the friend request was declined
                                self.messageLabel.text = "The friend request was declined"
                            }))
                            
                            // present the alert

                            self.present(controller, animated: true)
                        }
                    }
                }
            }
        }
    }
}
