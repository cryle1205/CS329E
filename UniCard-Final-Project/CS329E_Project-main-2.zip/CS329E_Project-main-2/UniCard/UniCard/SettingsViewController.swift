//
//  SettingsViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 10/13/22.
//
import UIKit
import CoreData
import FirebaseAuth
import FirebaseFirestore

// global variables to indicate when dark, sound, or haptics are on/off
var hapticModeFlag: Bool = false
var darkModeFlag: Bool = false
var soundModeFlag: Bool = true

// user defaults method 
let defaults = UserDefaults.standard

class SettingsViewController: UIViewController {
    
    // outlets connected from the story board
    @IBOutlet weak var soundSegCtrl: UISegmentedControl!
    @IBOutlet weak var hapticMode: UISwitch!
    @IBOutlet weak var darkMode: UISwitch!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // check last stored user defaults and set the outlets to the correct state
        if defaults.bool(forKey: "darkModeFlag") == true {
            darkMode.setOn(true, animated: true)
        } else {
            darkMode.setOn(false, animated: true)
        }
        
        // check last stored defaults for haptics
        if defaults.bool(forKey: "hapticModeFlag") == true {
            hapticMode.setOn(true, animated: true)
        } else {
            hapticMode.setOn(false, animated: true)
        }
        
        // check last stored defaults for sound
        if defaults.bool(forKey: "soundModeFlag") == true {
            soundSegCtrl.selectedSegmentIndex = 0
        } else {
            soundSegCtrl.selectedSegmentIndex = 1
        }
    }
    
    // function to turn on Dark Mode and change indicators across the project
    @IBAction func darkModeSwitch(_ sender: Any) {
        
        // dark Mode is On, turn the flag to true, store user default setting preferences, and turn it on
        if darkMode.isOn == true {
            overrideUserInterfaceStyle = .dark
            darkModeFlag = true
            defaults.set(true, forKey: "darkModeFlag")
         // dark Mode is Off, turn the flag to false, store user default setting preferences, and turn it off
        } else {
            overrideUserInterfaceStyle = .light
            darkModeFlag = false
            defaults.set(false, forKey: "darkModeFlag")
        }
    }
    
    // function to turn on haptic Mode and change indicators across the project
    @IBAction func hapticModeSwitch(_ sender: Any) {
        
         // haptic Mode is On, turn the flag to true, store user default setting preferences, and turn it on
        if hapticMode.isOn == true {
            hapticModeFlag = true
            defaults.set(true, forKey: "hapticModeFlag")
         // haptic Mode is Off, turn the flag to false, store user default setting preferences, and turn it off
        } else {
            hapticModeFlag = false
            defaults.set(false, forKey: "hapticModeFlag")
        }
    }
    
    // function to turn on sound on and change indicators across the project
    @IBAction func soundSegCtrlPressed(_ sender: Any) {

        switch soundSegCtrl.selectedSegmentIndex {
             // sound On, turn the flag to true, store user default setting preferences, and turn it on
           case 0:
               soundModeFlag = true
               defaults.set(true, forKey: "soundModeFlag")
            // sound Off, turn the flag to false, store user default setting preferences, and turn it off
           case 1:
                soundModeFlag = false
                defaults.set(false, forKey: "soundModeFlag")
           default:
               break
        }
    }
    
    // used to logout current user
    @IBAction func logout(_ sender: Any) {
        do {
            
            // sign out the current user on firebase, clear coredata, and return to login screen
            try Auth.auth().signOut()
            clearCoreData()
            coreUserID = ""
            self.view.window!.rootViewController?.dismiss(animated: false, completion: nil)
        } catch {
            print ("Sign out error")
        }
    }
    
    // used to delete current user
    @IBAction func deleteAccountPressed(_ sender: Any) {
        
        // reference to current user
        let user = Auth.auth().currentUser
        
        // reference to user document on firestore
        let ref = db.collection("Users").document("\(Auth.auth().currentUser!.uid)")
        
        // delete the document
        ref.delete() { err in
            if let err = err {
                print("Error removing document: \(err)")
            } else {
                print("Document successfully removed!")
            }
        }
        
        // delete the user
        user?.delete { error in
            if error != nil {
            // An error happened.
          } else {
            // Account deleted.
          }
        }
        
        // sign out the current user on firebase, clear coredata, and return to login screen
        do {
            try Auth.auth().signOut()
            clearCoreData()
            coreUserID = ""
            self.view.window!.rootViewController?.dismiss(animated: false, completion: nil)
        } catch {
            print ("Sign out error")
        }
    }
    
    // erase the information in core data
    func clearCoreData() {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        var fetchedResults:[NSManagedObject]
        
        do {
            try fetchedResults = context.fetch(request) as! [NSManagedObject]
            
            if fetchedResults.count > 0 {
                for result:AnyObject in fetchedResults {
                    context.delete(result as! NSManagedObject)
                    print("\(result.value(forKey: "coreUserID")!) has been deleted")
                }
            }
            // save the changes made to core data
            saveContext()
        } catch {
            // if an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }
    
    // save the information onto core data
    func saveContext () {
        
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // if an error occurs
                let nserror = error as NSError
                NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}
