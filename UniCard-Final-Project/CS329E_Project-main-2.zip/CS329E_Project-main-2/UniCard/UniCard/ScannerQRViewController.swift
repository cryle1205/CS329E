//
//  ScannerQRViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 11/3/22.
//
import UIKit

class ScannerQRViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // used to add darkmode to the view controller
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
    }
}
