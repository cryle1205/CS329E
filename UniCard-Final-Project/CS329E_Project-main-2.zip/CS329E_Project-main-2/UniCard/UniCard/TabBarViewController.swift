//
//  TabBarViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 10/14/22.
//
import UIKit
import AVFoundation

class TabBarViewController: UITabBarController, UITabBarControllerDelegate {
    
    let systemSoundID: SystemSoundID = 1016
    var tabBarDelegate: UIViewController!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        
        // check to see upon loading if haptics are on for tab bar
        // makes sure that even when re-logging in, it checks last user defaults
        if defaults.object(forKey: "hapticModeFlag") == nil || defaults.bool(forKey: "hapticModeFlag") == false {
            hapticModeFlag = false
        } else if defaults.bool(forKey: "hapticModeFlag") == true {
            hapticModeFlag = true
            self.reloadInputViews()
        }
        
        // check to see upon loading if sound are on for tab bar
        if defaults.object(forKey: "soundModeFlag") == nil || defaults.bool(forKey: "soundModeFlag") == false {
            soundModeFlag = false
        } else if defaults.bool(forKey: "soundModeFlag") == true {
            soundModeFlag = true
            self.reloadInputViews()
        }
    }
    
    // used check sound and haptics settings when tab bar items are selected
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        
        // check haptics and sound and have functions play out if their flag is true
        if hapticModeFlag == true && soundModeFlag == true {
            let generator = UIImpactFeedbackGenerator(style: .medium)
            generator.impactOccurred()
            AudioServicesPlaySystemSound(systemSoundID)
        } else if hapticModeFlag == false && soundModeFlag == true {
            AudioServicesPlaySystemSound(systemSoundID)
        } else if hapticModeFlag == true && soundModeFlag == false {
            let generator = UIImpactFeedbackGenerator(style: .medium)
            generator.impactOccurred()
        } else {
            // if flags are all false, then haptics and sound will not play out
            return
        }
    }
    
    // used to add darkmode to the view controller
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
    }
}
