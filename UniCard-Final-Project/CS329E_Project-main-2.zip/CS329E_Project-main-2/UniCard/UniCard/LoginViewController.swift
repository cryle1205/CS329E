//
//  LoginViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 10/13/22.
//
import UIKit
import FirebaseAuth
import CoreData

// create a reference to appDelegate
let appDelegate = UIApplication.shared.delegate as! AppDelegate
public let context = appDelegate.persistentContainer.viewContext

// create a custom color
public let utOrange = UIColor(named: "UTOrange")

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    // create outlets for textfields and labels
    var loginDelegate: UIViewController!

    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create user default for darkmode setting
        if defaults.object(forKey: "darkModeFlag") == nil || defaults.bool(forKey: "darkModeFlag") == false {
            darkModeFlag = false
        } else if defaults.bool(forKey: "darkModeFlag") == true {
            darkModeFlag = true
            self.reloadInputViews()
        }
        
        usernameField.delegate = self
        passwordField.delegate = self
        passwordField.isSecureTextEntry = true
        
        // notices whether there is a change or active log in
        Auth.auth().addStateDidChangeListener(){
            auth, user in
            if user != nil {
                
                // store the new user UID
                self.storeUserID(userID: Auth.auth().currentUser!.uid)
                
                // perform segue onto next view controller
                self.performSegue(withIdentifier: "loadingScreenSegue", sender: self)
                self.usernameField.text = nil
                self.passwordField.text = nil
            } else {
                self.statusLabel.text = ""
            }
        }
    }
    
    // adds darkmode setting to this view controller
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
    }
    
    @IBAction func loginPressed(_ sender: Any) {
        
        // sign the user in with the entered username and password
        Auth.auth().signIn(withEmail: usernameField.text!, password: passwordField.text!) {
            authResult, error in
            if let error = error as NSError? {
                
                // if an error occurs then print the error description in the status label
                self.statusLabel.text = "\(error.localizedDescription)"
            }
            else
            {
                
                // if successful then print login successful
                self.statusLabel.text = "Login Sucessful"
            }
        }
    }
    
    @IBAction func forgotPasswordPressed(_ sender: Any) {
        
        // create an alert for the user to enter their username to have an email sent to them to reset their password
        let controller = UIAlertController(
            title: "Alert Controller",
            message: "Please enter your username to reset password.",
            preferredStyle: .alert)
        
        // cancel action to exit alert
        controller.addAction(UIAlertAction(
            title: "Cancel",
            style: .cancel))
        
        // text field to enter username
        controller.addTextField(configurationHandler: {
            (textField:UITextField!) in
            textField.placeholder = "Username"
        })
        
        // ok action to send forgot email password
        controller.addAction(UIAlertAction(
            title: "OK",
            style: .default,
            handler: {
                (paramAction:UIAlertAction!) in
                if let textFieldArray = controller.textFields {
                    let textFields = textFieldArray as [UITextField]
                    
                    // text that user typed
                    let enteredText = textFields[0].text
                    
                    // send email to the email that the user typed into the text field
                    Auth.auth().sendPasswordReset(withEmail: enteredText!) { error in
                    }
                }
            }
        ))
        // present the alert
        present(controller, animated: true)
    }
    
    // used to store the current user UID into core data
    func storeUserID(userID: String) {
        
        let user = NSEntityDescription.insertNewObject(forEntityName: "User", into: context)
        
        user.setValue(userID, forKey: "coreUserID")
        saveContext()
    }
    
    // save the information into core data
    func saveContext () {
        
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // error message if it occurs
                let nserror = error as NSError
                NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    // Called when 'return' key pressed
    func textFieldShouldReturn(_ textField:UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user clicks on the view outside of the UITextField
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true)
    }
}
