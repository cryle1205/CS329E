//
//  LoadingViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 11/27/22.
//
import UIKit
import Firebase

class LoadingViewController: UIViewController {
    
    @IBOutlet weak var leftIcon: UIImageView!
    @IBOutlet weak var rightIcon: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        performSegue(withIdentifier: "loadingTabSegue", sender: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(
            withDuration: 0.7,
            delay: 1.0,
            options: .curveEaseOut,
            animations: {
                self.leftIcon.frame.origin.x -= self.leftIcon.frame.size.width + 15
                self.rightIcon.frame.origin.x += self.rightIcon.frame.size.width + 15
            },
            completion: { finished in
                self.performSegue(withIdentifier: "loadingTabSegue", sender: nil)
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
    }
}
