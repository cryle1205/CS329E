//
//  EditProfileViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 10/13/22.
//
import UIKit
import FirebaseAuth
import Firebase
import FirebaseCore
import FirebaseFirestore
import FirebaseStorage

class EditProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    
    // create an image picker
    let picker = UIImagePickerController()
    
    // create outlets for textfields, labels, buttons, and imageviews
    @IBOutlet weak var profileView: UIImageView!
    @IBOutlet weak var editFirst: UITextField!
    @IBOutlet weak var editLast: UITextField!
    @IBOutlet weak var editClassification: UIButton!
    @IBOutlet weak var editMajor: UIButton!
    @IBOutlet weak var editPhoneNumber: UITextField!
    @IBOutlet weak var editBio: UITextField!
    @IBOutlet weak var editUsername: UITextField!
    @IBOutlet weak var editPassword: UITextField!
    @IBOutlet weak var editConfirmPassword: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var oldPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
        editFirst.delegate = self
        editLast.delegate = self
        editPhoneNumber.delegate = self
        editBio.delegate = self
        editUsername.delegate = self
        editPassword.delegate = self
        editConfirmPassword.delegate = self
        oldPassword.delegate = self
        statusLabel.text = ""
        
        // make the following passwords secure entry
        oldPassword.isSecureTextEntry = true
        editPassword.isSecureTextEntry = true
        editConfirmPassword.isSecureTextEntry = true
        
        // function call to create the menus for classification and major
        chooseClassification()
        chooseMajor()
        
        // makes the imageview a circle
        profileView.layer.borderWidth = 1.0
        profileView.layer.masksToBounds = false
        profileView.layer.borderColor = UIColor.white.cgColor
        profileView.layer.cornerRadius = profileView.layer.frame.size.width / 2
        profileView.clipsToBounds = true
    }
    
    // function to give the classification menu options
    func chooseClassification() {
        
        // list of classifications
        let classList = ["Freshman", "Sophomore", "Junior", "Senior"]
        
        var childrenList:[UIAction] = []
        
        // append the list of classifications to the classification menu
        for i in classList {
            childrenList.append(UIAction(title: i, state: .on, handler:
                                            {(action: UIAction) in
                
                // once an option is selected, change the appearance of the menu
                self.editClassification.configuration = .filled()
                self.editClassification.configuration?.baseBackgroundColor = utOrange
                self.editClassification.configuration?.baseForegroundColor = .black
                                               }))
        }
        
        // create the menu based on the information above
        editClassification.menu = UIMenu(children: childrenList)
        editClassification.showsMenuAsPrimaryAction = true
        editClassification.changesSelectionAsPrimaryAction = true
    }
    
    // function to give the major menu options
    func chooseMajor() {
        
        // list of majors
        let majorList = ["ACCOUNTING", "ACTUARIAL SCIENCE", "ADVERTISING AND PUBLIC RELATIONS", "AEROSPACE ENGINEERING", "AGRICULTURAL ECONOMICS", "AGRICULTURE PRODUCTION AND MANAGEMENT", "ANIMAL SCIENCES", "ANTHROPOLOGY AND ARCHEOLOGY", "APPLIED MATHEMATICS", "ARCHITECTURAL ENGINEERING", "ARCHITECTURE", "AREA ETHNIC AND CIVILIZATION STUDIES", "ART AND MUSIC EDUCATION", "ART HISTORY AND CRITICISM", "ASTRONOMY AND ASTROPHYSICS", "ATMOSPHERIC SCIENCES AND METEOROLOGY", "BIOCHEMICAL SCIENCES", "BIOLOGICAL ENGINEERING", "BIOLOGY", "BIOMEDICAL ENGINEERING", "BOTANY", "BUSINESS ECONOMICS", "BUSINESS MANAGEMENT AND ADMINISTRATION", "CHEMICAL ENGINEERING", "CHEMISTRY", "CIVIL ENGINEERING", "CLINICAL PSYCHOLOGY", "COGNITIVE SCIENCE AND BIOPSYCHOLOGY", "COMMERCIAL ART AND GRAPHIC DESIGN", "COMMUNICATION DISORDERS SCIENCES AND SERVICES", "COMMUNICATION TECHNOLOGIES", "COMMUNICATIONS", "COMMUNITY AND PUBLIC HEALTH", "COMPOSITION AND RHETORIC", "COMPUTER ADMINISTRATION MANAGEMENT AND SECURITY", "COMPUTER AND INFORMATION SYSTEMS", "COMPUTER ENGINEERING", "COMPUTER NETWORKING AND TELECOMMUNICATIONS", "COMPUTER PROGRAMMING AND DATA PROCESSING", "COMPUTER SCIENCE", "CONSTRUCTION SERVICES", "COSMETOLOGY SERVICES AND CULINARY ARTS", "COUNSELING PSYCHOLOGY", "COURT REPORTING", "CRIMINAL JUSTICE AND FIRE PROTECTION", "CRIMINOLOGY", "DRAMA AND THEATER ARTS", "EARLY CHILDHOOD EDUCATION", "ECOLOGY", "ECONOMICS", "EDUCATIONAL ADMINISTRATION AND SUPERVISION", "EDUCATIONAL PSYCHOLOGY", "ELECTRICAL ENGINEERING", "ELECTRICAL ENGINEERING TECHNOLOGY", "ELECTRICAL, MECHANICAL, AND PRECISION TECHNOLOGIES AND PRODUCTION", "ELEMENTARY EDUCATION", "ENGINEERING AND INDUSTRIAL MANAGEMENT", "ENGINEERING MECHANICS PHYSICS AND SCIENCE", "ENGINEERING TECHNOLOGIES", "ENGLISH LANGUAGE AND LITERATURE", "ENVIRONMENTAL ENGINEERING", "ENVIRONMENTAL SCIENCE", "FAMILY AND CONSUMER SCIENCES", "FILM VIDEO AND PHOTOGRAPHIC ARTS", "FINANCE", "FINE ARTS", "FOOD SCIENCE", "FORESTRY", "FRENCH GERMAN LATIN AND OTHER COMMON FOREIGN LANGUAGE STUDIES", "GENERAL AGRICULTURE", "GENERAL BUSINESS", "GENERAL EDUCATION", "GENERAL ENGINEERING", "GENERAL MEDICAL AND HEALTH SERVICES", "GENERAL SOCIAL SCIENCES", "GENETICS", "GEOGRAPHY", "GEOLOGICAL AND GEOPHYSICAL ENGINEERING", "GEOLOGY AND EARTH SCIENCE", "GEOSCIENCES", "HEALTH AND MEDICAL ADMINISTRATIVE SERVICES", "HEALTH AND MEDICAL PREPARATORY PROGRAMS", "HISTORY", "HOSPITALITY MANAGEMENT", "HUMAN RESOURCES AND PERSONNEL MANAGEMENT", "HUMAN SERVICES AND COMMUNITY ORGANIZATION", "HUMANITIES", "INDUSTRIAL AND MANUFACTURING ENGINEERING", "INDUSTRIAL AND ORGANIZATIONAL PSYCHOLOGY", "INDUSTRIAL PRODUCTION TECHNOLOGIES", "INFORMATION SCIENCES", "INTERCULTURAL AND INTERNATIONAL STUDIES", "INTERDISCIPLINARY SOCIAL SCIENCES", "INTERNATIONAL BUSINESS", "INTERNATIONAL RELATIONS", "JOURNALISM", "LANGUAGE AND DRAMA EDUCATION", "LIBERAL ARTS", "LIBRARY SCIENCE", "LINGUISTICS AND COMPARATIVE LANGUAGE AND LITERATURE", "MANAGEMENT INFORMATION SYSTEMS AND STATISTICS", "MARKETING AND MARKETING RESEARCH", "MASS MEDIA", "MATERIALS ENGINEERING AND MATERIALS SCIENCE", "MATERIALS SCIENCE", "MATHEMATICS", "MATHEMATICS AND COMPUTER SCIENCE", "MATHEMATICS TEACHER EDUCATION", "MECHANICAL ENGINEERING", "MECHANICAL ENGINEERING RELATED TECHNOLOGIES", "MEDICAL ASSISTING SERVICES", "MEDICAL TECHNOLOGIES TECHNICIANS", "METALLURGICAL ENGINEERING", "MICROBIOLOGY", "MILITARY TECHNOLOGIES", "MINING AND MINERAL ENGINEERING", "MISCELLANEOUS AGRICULTURE", "MISCELLANEOUS BIOLOGY", "MISCELLANEOUS BUSINESS & MEDICAL ADMINISTRATION", "MISCELLANEOUS EDUCATION", "MISCELLANEOUS ENGINEERING", "MISCELLANEOUS ENGINEERING TECHNOLOGIES", "MISCELLANEOUS FINE ARTS", "MISCELLANEOUS HEALTH MEDICAL PROFESSIONS", "MISCELLANEOUS PSYCHOLOGY", "MISCELLANEOUS SOCIAL SCIENCES", "MOLECULAR BIOLOGY", "MULTI-DISCIPLINARY OR GENERAL SCIENCE", "MULTI/INTERDISCIPLINARY STUDIES", "MUSIC", "N/A (less than bachelor's degree)", "NATURAL RESOURCES MANAGEMENT", "NAVAL ARCHITECTURE AND MARINE ENGINEERING", "NEUROSCIENCE", "NUCLEAR ENGINEERING", "NUCLEAR, INDUSTRIAL RADIOLOGY, AND BIOLOGICAL TECHNOLOGIES", "NURSING", "NUTRITION SCIENCES", "OCEANOGRAPHY", "OPERATIONS LOGISTICS AND E-COMMERCE", "OTHER FOREIGN LANGUAGES", "PETROLEUM ENGINEERING", "PHARMACOLOGY", "PHARMACY PHARMACEUTICAL SCIENCES AND ADMINISTRATION", "PHILOSOPHY AND RELIGIOUS STUDIES", "PHYSICAL AND HEALTH EDUCATION TEACHING", "PHYSICAL FITNESS PARKS RECREATION AND LEISURE", "PHYSICAL SCIENCES", "PHYSICS", "PHYSIOLOGY", "PLANT SCIENCE AND AGRONOMY", "POLITICAL SCIENCE AND GOVERNMENT", "PRE-LAW AND LEGAL STUDIES", "PSYCHOLOGY", "PUBLIC ADMINISTRATION", "PUBLIC POLICY", "SCHOOL STUDENT COUNSELING", "SCIENCE AND COMPUTER TEACHER EDUCATION", "SECONDARY TEACHER EDUCATION", "SOCIAL PSYCHOLOGY", "SOCIAL SCIENCE OR HISTORY TEACHER EDUCATION", "SOCIAL WORK", "SOCIOLOGY", "SOIL SCIENCE", "SPECIAL NEEDS EDUCATION", "STATISTICS AND DECISION SCIENCE", "STUDIO ARTS", "TEACHER EDUCATION: MULTIPLE LEVELS", "THEOLOGY AND RELIGIOUS VOCATIONS", "TRANSPORTATION SCIENCES AND TECHNOLOGIES", "TREATMENT THERAPY PROFESSIONS", "UNITED STATES HISTORY", "VISUAL AND PERFORMING ARTS", "ZOOLOGY"]
        
        var childrenList:[UIAction] = []
        
        // append the list of majors to the majors menu
        for i in majorList {
            childrenList.append(UIAction(title: i, state: .on, handler:
                                            {(action: UIAction) in
                
                // once an option is selected, change the appearance of the menu
                self.editMajor.configuration = .filled()
                self.editMajor.configuration?.baseBackgroundColor = utOrange
                self.editMajor.configuration?.baseForegroundColor = .black
                                               }))
        }
        
        // create the menu based on the information above
        editMajor.menu = UIMenu(children: childrenList)
        editMajor.showsMenuAsPrimaryAction = true
        editMajor.changesSelectionAsPrimaryAction = true
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // adds darkmode setting to this view controller
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
        
        // create a reference to the firestore document associated with the current user
        let ref = db.collection("Users").document("\(Auth.auth().currentUser!.uid)")
        
        // retrieve the information from that document
        ref.getDocument { (document, error) in
            if let document = document, document.exists {
                let classification = document.get("classification") as! String
                let major = document.get("major") as! String
                let imageURL = document.get("imageURL") as! String
                self.editClassification.setTitle(classification, for: .normal)
                self.editMajor.setTitle(major, for: .normal)
                let url = URL(string: imageURL)!
                let session = URLSession(configuration: .default)
                
                // Create a task for accessing the image
                let task = session.dataTask(with: url) {
                    (data, response, error) in

                    guard error == nil else { return }

                    if let httpResponse = response as? HTTPURLResponse {

                        // ensure that we got a response code of 200 (which means "success")
                        guard httpResponse.statusCode == 200 else { return }

                        if let receivedData = data {
                            DispatchQueue.main.async {
                                
                                // set the edit profile image equal to the current image from firestore
                                self.profileView.image = UIImage(data: receivedData)
                            }
                        }
                    }
                }
                task.resume()
            }
            else {
                print("Document does not exist")
            }
        }
    }
    
    @IBAction func changePictureButtonPressed(_ sender: Any) {
        
        // define settings of image picker and present
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        // create a variable equal to the image the user chose
        let chosenImage = info[.originalImage] as! UIImage
        
        // set the edit profile image on the edit profile view controller equal to the chosen image
        self.profileView.image = chosenImage
        
        // get image data of the new edit profile image
        guard let imageData = chosenImage.pngData() else {
            return
        }
        
        // store the data into firebase storage
        storage.child("Users").child("\(Auth.auth().currentUser!.uid).png").putData(imageData, metadata: nil, completion: { _, error in
            guard error == nil else {
                print("Failed to upload")
                return
            }
            
            // download the corresponding url of the image
            storage.child("Users").child("\(Auth.auth().currentUser!.uid).png").downloadURL(completion: {url, error in
                guard let url = url, error == nil else {
                    return
                }
                    
                // create a variable equal to the image url
                let urlString = url.absoluteString
                
                // save all the image url into firestore into a document named the user UID
                db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData([
                    "imageURL": urlString
                ], merge:true) { err in
                    if let err = err {
                        print("Error adding document: \(err)")
                    } else {
                        print("Successful adding document!!!")
                    }
                }
            })
        })
        dismiss(animated: true)
    }
    
    // once an image is chosen, the image picker will disappear
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }
    
    // update the firestore information when button is pressed
    @IBAction func saveChangesButtonPressed(_ sender: Any) {
        
        // change the password if new information was put into the textfields
        if editPassword.text! != "" && editConfirmPassword.text! != "" {
            
            // change the password if the edited password is equal to the confirmed password
            if (editPassword.text! == editConfirmPassword.text!) {
                
                // create variables equal to the user, user email, and user password
                let user = Auth.auth().currentUser
                let email = Auth.auth().currentUser?.email ?? ""
                let old = oldPassword.text!
                
                // create a credential using the information above
                let credential = EmailAuthProvider.credential(withEmail: email, password: old)

                // reauthenticate the user with the credentials
                user?.reauthenticate(with: credential) { authResult, error in
                    if error != nil {
                        self.statusLabel.text! = "The old password does not match"
                    }
                    else {
                        
                        // update the password if the credentials are correct
                        FirebaseAuth.Auth.auth().currentUser!.updatePassword(to: self.editPassword.text!) { error in
                            if let error = error as NSError? {
                                self.statusLabel.text = "\(error.localizedDescription)"
                            }
                            else {
                                self.statusLabel.text! = "Updated Information"
                            }
                        }
                    }
                }
            }
            
            // if the new password does not match the confirmed password, then use the status label to notify user
            else if (editPassword.text! != editConfirmPassword.text!) {
                self.statusLabel.text = "New password does not match confirmed password"
            }
        }
        
        // change username if new information was put into the text field
        if editUsername.text! != "" {
            
            // create variables equal to the user, user email, and user password
            let user = Auth.auth().currentUser
            let email = Auth.auth().currentUser?.email ?? ""
            let old = oldPassword.text!
            
            // create a credential using the information above
            let credential = EmailAuthProvider.credential(withEmail: email, password: old)

            // reauthenticate the user with the credentials
            user?.reauthenticate(with: credential) { [self] authResult, error in
                if error != nil {
                    statusLabel.text! = "Please enter old password to change username"
                }
                else {
                    
                    // update the username if the credentials are correct
                    FirebaseAuth.Auth.auth().currentUser?.updateEmail(to: self.editUsername.text!) { error in
                        if let error = error as NSError? {
                            self.statusLabel.text = "\(error.localizedDescription)"
                        }
                        else {
                            
                            // save the new username into firestore under the same UID document
                            db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData(["email": self.editUsername.text!], merge:true) { err in
                                if let err = err {
                                    print("Error adding document: \(err)")
                                } else {
                                    print("Successful adding document")
                                }
                            }
                            self.statusLabel.text! = "Updated Information"
                        }
                    }
                }
            }
        }
        
        // change first name if new information was put into the text field
        if editFirst.text! != "" {
            
            // save the new first name into firestore under the same UID document
            db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData(["first": self.editFirst.text!], merge:true) { err in
                if let err = err {
                    print("Error adding document: \(err)")
                } else {
                    print("Successful adding document")
                }
            }
            self.statusLabel.text! = "Updated Information"
        }
        
        // change last name if new information was put into the text field
        if editLast.text! != "" {
            
            // save the new last name into firestore under the same UID document
            db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData(["last": self.editLast.text!], merge:true) { err in
                if let err = err {
                    print("Error adding document: \(err)")
                } else {
                    print("Successful adding document")
                }
            }
            self.statusLabel.text! = "Updated Information"
        }
        
        // change phone number if new information was put into the text field
        if editPhoneNumber.text! != "" {
            
            // save the new phone number into firestore under the same UID document
            db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData(["pNumber": self.editPhoneNumber.text!], merge:true) { err in
                if let err = err {
                    print("Error adding document: \(err)")
                } else {
                    print("Successful adding document")
                }
            }
            self.statusLabel.text! = "Updated Information"
        }
        
        // change bio if new information was put into the text field
        if editBio.text! != "" {
            
            // save the new bio into firestore under the same UID document
            db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData(["otherInfo": self.editBio.text!], merge:true) { err in
                if let err = err {
                    print("Error adding document: \(err)")
                } else {
                    print("Successful adding document")
                }
            }
            self.statusLabel.text! = "Updated Information"
        }
        
        // create a reference to the firestore document associated with the current user
        let ref = db.collection("Users").document("\(Auth.auth().currentUser!.uid)")
        
        // retrieve the information from that document
        ref.getDocument { (document, error) in
            if let document = document, document.exists {
                let classification = document.get("classification") as! String
                let major = document.get("major") as! String
                
                // if the current classification is not the same as the saved user information, then update firestore
                if classification != self.editClassification.currentTitle! {
                    db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData(["classification": self.editClassification.currentTitle!], merge:true) { err in
                        if let err = err {
                            print("Error adding document: \(err)")
                        } else {
                            print("Successful adding document")
                            self.statusLabel.text! = "Updated Information"
                        }
                    }
                }
                
                // if the current major is not the same as the saved user information, then update firestore
                if major != self.editMajor.currentTitle! {
                    db.collection("Users").document("\(Auth.auth().currentUser!.uid)").setData(["major": self.editMajor.currentTitle!], merge:true) { err in
                        if let err = err {
                            print("Error adding document: \(err)")
                        } else {
                            print("Successful adding document")
                            self.statusLabel.text! = "Updated Information"
                        }
                    }
                }
            }
            else {
                print("Document does not exist")
            }
        }
    }
    
    // called when 'return' key pressed
    func textFieldShouldReturn(_ textField:UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user clicks on the view outside of the UITextField
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
