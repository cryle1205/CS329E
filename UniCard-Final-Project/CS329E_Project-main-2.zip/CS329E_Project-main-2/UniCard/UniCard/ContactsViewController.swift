//
//  ContactsViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 10/13/22.
//
import UIKit
import FirebaseCore
import FirebaseFirestore

// create a list of the user's friends' UIDs
public var contactList:[String] = []

class ContactsViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // add darkmode to the view controller
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
        
        // create a reference to the document associated with the current user UID
        let ref = db.collection("Users").document("\(coreUserID)")
        
        // retrive information from the document
        ref.getDocument { (document, error) in
            if let document = document, document.exists {
                let friends = document.get("friends") as! Array<String>
                
                // save contactlist as the array given from the document
                contactList = friends
                
                // reload the table data
                self.tableView.reloadData()
            }
            else {
                print("Document does not exist")
            }
        }
    }
        

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        let cell = tableView.dequeueReusableCell(withIdentifier: "textCellIdentifier", for: indexPath)
        
        // set number of lines for each cell
        cell.textLabel?.numberOfLines = 1
        
        // create custom font and set custom font for each cell
        let customFont = UIFont(name: "DIN Alternate Bold", size: 20)
        cell.textLabel?.font = customFont
        
        // call on getDocument function and set each cell equal to the name of each friend on contactList
        getDocument(path: contactList[row]) {(value) in cell.textLabel?.text = "\(value)"}
        return cell
    }
    
    // used to retrieve information from each friend in the contactList using their UID
    func getDocument(path: String, completion:@escaping(Any)->()) {
        var returnVar : Any = "DEFAULT VAL"

        // create a reference to the friend's UID document
        let ref = db.collection("Users").document("\(path)")
        
        // retrieve the information from the document
        ref.getDocument { (document, error) in
            if let document = document, document.exists {

                let first =  document.get("first") ?? "nil"
                let last = document.get("last") ?? "nil"
                returnVar = "\(first) \(last)"
                
                // return the first and last name of the friend
                completion(returnVar)
            }
            else {
                print("Document does not exist")
                returnVar = -1
                completion(returnVar)
            }
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the number of rows in contact list
        return contactList.count
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // perform the segue to the selected cell and move the friend's UID into the next view controller
        if segue.identifier == "TableContactSegue",
           let tableProfileVC = segue.destination as? TableProfileViewController,
           let index = tableView.indexPathForSelectedRow?.row {
            tableProfileVC.tableUserID = contactList[index]
        }
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        // used to delete the friend from the contact list and update firestore accordingly
        if editingStyle == .delete {
            let ref = db.collection("Users").document("\(coreUserID)")
            print(contactList[indexPath.row])
            ref.updateData(["friends": FieldValue.arrayRemove([contactList[indexPath.row]])])
            contactList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}
