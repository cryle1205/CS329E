//
//  ProfileViewController.swift
//  UniCard
//
//  Created by Catherine Kim, Crystal Le, Dustin Nguyen, Johnny Tran on 10/13/22.
//
import UIKit
import CoreData
import EventKit
import EventKitUI
import Firebase

public var coreUserID = ""

class ProfileViewController: UIViewController,  EKEventEditViewDelegate {
    func eventEditViewController(_ controller: EKEventEditViewController, didCompleteWith action: EKEventEditViewAction) {
        controller.dismiss(animated: true, completion: nil)
        
    }

    var savedEventID = ""
    let eventStore = EKEventStore()
    var time = Date()

    // create outlets for labels, buttons, and imageviews
    @IBOutlet weak var addEvent: UIButton!
    @IBOutlet weak var majorLabel: UILabel!
    @IBOutlet weak var classificationLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var bioLabel: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // retrieve userID from core data
        let fetchedResults = retrieveUserID()
        for i in fetchedResults {
            if let userID = i.value(forKey: "coreUserID") {
                coreUserID = "\(userID)"
            }
        }
        bioLabel.sizeToFit()
        
        // makes the imageview a circle
        profileImage.layer.borderWidth = 1.0
        profileImage.layer.masksToBounds = false
        profileImage.layer.borderColor = UIColor.white.cgColor
        profileImage.layer.cornerRadius = profileImage.layer.frame.size.width / 2
        profileImage.clipsToBounds = true
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // adds darkmode setting to this view controller
        if darkModeFlag == true {
            overrideUserInterfaceStyle = .dark
        } else {
            overrideUserInterfaceStyle = .light
        }
        
        majorLabel.text! = ""
        classificationLabel.text! = ""
        nameLabel.text! = ""
        phoneLabel.text! = ""
        emailLabel.text! = ""
        bioLabel.text! = ""
            
        // create a reference to the firestore document associated with the current user
        let ref = db.collection("Users").document("\(Auth.auth().currentUser!.uid)")

        // retrieve the information from that document
        ref.getDocument { (document, error) in
            if let document = document, document.exists {
                let first = document.get("first") as! String
                let last = document.get("last") as! String
                let classification = document.get("classification") as! String
                let major = document.get("major") as! String
                let otherInfo = document.get("otherInfo") as! String
                let email = document.get("email") as! String
                let pNumber = document.get("pNumber") as! String
                let imageURL = document.get("imageURL") as! String
                self.majorLabel.text! = major
                self.classificationLabel.text! = classification
                self.nameLabel.text! = "\(first) \(last)"
                self.phoneLabel.text! = pNumber
                self.emailLabel.text! = email
                self.bioLabel.text! = otherInfo

                // create url from firestore document associated with user
                let url = URL(string: imageURL)!
                let session = URLSession(configuration: .default)
                
                // Create a task for accessing the image
                let task = session.dataTask(with: url) {
                    (data, response, error) in

                    guard error == nil else { return }

                    if let httpResponse = response as? HTTPURLResponse {

                        // ensure that we got a response code of 200 (which means "success")
                        guard httpResponse.statusCode == 200 else { return }

                        if let receivedData = data {
                            DispatchQueue.main.async {
                                
                                // set the profile image equal to the current image gathered from firestore
                                self.profileImage.image = UIImage(data: receivedData)
                            }
                        }
                    }
                }
                task.resume()
            }
            else {
                print("Document does not exist")
            }
        }
    }
    
    @IBAction func addEvent(_ sender: Any) {
        
        let event = EKEvent(eventStore: self.eventStore)
        
        //allows user to create an event in their apple calendar
        eventStore.requestAccess( to: EKEntityType.event, completion:{(granted, error) in
            DispatchQueue.main.async { [self] in
                if (granted) && (error == nil) {
                    event.title = ""
                    event.startDate = self.time
                    event.url = URL(string: "")
                    event.endDate = self.time
                    let eventController = EKEventEditViewController()
                    eventController.event = event
                    eventController.eventStore = self.eventStore
                    eventController.editViewDelegate = self
                    self.present(eventController, animated: true, completion: nil)
                }
            }
        })
    }
    
    // used to retrive the information from core data
    func retrieveUserID() -> [NSManagedObject] {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            // if an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        return(fetchedResults)!
    }
}
