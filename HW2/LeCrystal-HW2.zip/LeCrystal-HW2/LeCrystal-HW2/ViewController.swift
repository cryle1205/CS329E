// Project: LeCrystal-HW2
// EID: CL44964
// Course: CS329E

import UIKit

// main class for the viewcontroller of HW2: Login Screen
class ViewController: UIViewController, UITextFieldDelegate {
    
    //Outet connections for text fields and the status label that is variable
    @IBOutlet weak var userField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    //Action function connected for logiin button
    @IBAction func buttonPressed(_ sender: Any) {
        
        //setting variables to the text found in the userField and passwordField
        let id = userField.text!
        let pw = passwordField.text!
        
        //checking to see if any of these fields are empty to reveal an error message in status field
        if (id.isEmpty) || (pw.isEmpty){
            statusLabel.text = "Invalid login"
        }
        //if both fields are not empty, the status label will display "userID logged in"
        else {
            let message = id + " logged in"
            statusLabel.text = message
        }
    }
    //Function: if pressing enter on keyboard, the on-screen keyboard will disappear
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    //Function: if touching anywhere on the background of the screen, the on-screen keyboard will disappear
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

