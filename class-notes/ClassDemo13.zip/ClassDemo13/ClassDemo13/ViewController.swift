//
//  ViewController.swift
//  ClassDemo13
//
//  Created by Crystal Le on 11/7/22.
//

import UIKit
import UserNotifications

var pickerData = ["1", "2", "3", "4", "5", "10", "20", "30"]

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    

    @IBOutlet weak var picker: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.picker.delegate = self
        self.picker.dataSource = self
    }
    
    @IBAction func scheduleBtnPressed(_ sender: Any) {
        //get selected value from the picker
        let pickerRow = picker.selectedRow(inComponent: 0)
        let pickerValue = Double(pickerData[pickerRow])!
        
        //create content
        let content = UNMutableNotificationContent()
        content.title = "Here's your notification"
        content.subtitle = "After \(pickerValue) seconds"
        content.sound = UNNotificationSound.default
        
        //creatte trigger
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: pickerValue, repeats: false)
        
        //combine itt all into a request
        let request = UNNotificationRequest(identifier: "myNotification", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request)
    }
    @IBAction func requestBtnPressed(_ sender: Any) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) {
            granted, error in
            if granted {
                print("All set")
            } else if let error = error {
                print(error.localizedDescription)
            }
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }

}

