//
//  ViewController.swift
//  ClassDemo6
//
//  Created by Crystal Le on 10/5/22.
//

import UIKit

var segueID = "popoverSegueIdentifier"

protocol ButtonSetter {
    func setButton(newString:String)
}

class ViewController: UIViewController , UIPopoverControllerDelegate, ButtonSetter{
    

    @IBOutlet weak var chooseButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueID {
            let popoverVC = segue.destination as! PopOverViewController
            popoverVC.delegate = self
            
            popoverVC.modalPresentationStyle = .popover
            popoverVC.popoverPresentationController?.delegate = self as? UIPopoverPresentationControllerDelegate
        }
    }
    
    func setButton(newString: String) {
        chooseButton.setTitle(newString, for: .normal)
    }
    

}

