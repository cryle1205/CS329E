// Two kinds of data types: named and compound

//NAMED: classes, structs, enumerations, protocols
//COMPOUND: tuples, functions

var president:(String,(String,String)) = ("Kennedy",
    ("John","Fitzgerald"))

typealias Point = (Int,Int)
var origin:Point = (10,20)

typealias LoopCounter = Int8

//mutable ("varying" variable)
var myName = "Bill"
//immutable (constant)
let myLastName = "Bulko"

myName = "Ed"
//myLastName = "Sheeran" <-- will give error


class Person{
    
    //instance variables
    var firstName:String
    let lastName:String
    
    init(first:String,last:String){
        firstName = first
        lastName = last
    }
}

//placeholders need input value
var singer = Person(first: "Michael", last: "Jackson")
singer.firstName = "Janet"

singer = Person(first: "Elvis", last: "Presley")

//string interpolation
print("\(singer.lastName), \(singer.firstName)")
var myName1 = "\(singer.lastName), \(singer.firstName)"

print("\(100 + 2), \(200)")
