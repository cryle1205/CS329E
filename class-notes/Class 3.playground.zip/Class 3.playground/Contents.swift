// Arrays:  collection of Ints or a specific class variable, cannot be strings and ints, etc

var teams = [1,2,3,4,5]
print(teams)

var team1 = teams[1]
teams[2] = 22
print(teams)

var teamsArray1:[Int] = [1,2,3,4,5]
var teamsArray2 = [Int]()
teamsArray2.append(5)
teamsArray2.append(8)
//CANNOT: teams.append("hello")

//count length of count
teams.count

//property method not class in swift

//Tuples
//type = string, double, bool
var myTuple = ("hello", 3.14, true)

//type = string, tuple(double)
var myOtherTuple = ("hello", (3.14, 98.6))

//name vs compound type
//name are simple/class
//cmpound are like arrays

//index for tuple
print(myTuple.2)
print(myOtherTuple.0)
print(myOtherTuple.1.0)

var myNewTuple = ("Mr.",
                  "Justin",
                  "Bieber",
                  "Jr.")
print(myNewTuple.2)

var myNewTuple1 = (prefix: "Mr.",
                   first:"Justin",
                   last: "Bieber",
                   suffix: "Jr.")
print(myNewTuple1.last)
print(myNewTuple1.2)

var name:(String,String) = ("Justin", "Bieber")
var (firstName, lastName) = name
print(firstName)
print(lastName)


//Flow Control

//Logical: && || !  and, or, not
//Relational: >  <  >=  <=  ==

var val1 = 100
var val2 = 200

if val1 == val2{
    print("they are equal")
} else if val1 > val2{
    print("val1 is bigger")
} else{
    print("val2 is bigger")
}

// for statement

for index in 1...3 {
    print("the count is \(index)")
}

for index in 1..<3 {
    print("the count is \(index)")
}

let names = ["Harry", "Zayn", "Louis", "Niall",
             "Liam"]

for name in names {
    print("Hello, \(name)!")
}

//while statements

//traditional pre-test format

var index = 0

while index < 5 {
    print("count is \(index)")
    index += 1
}

//traditional post-test format

var index2 = 0
repeat {
    print("count is \(index2)")
    index2 += 1
} while index2 < 5
