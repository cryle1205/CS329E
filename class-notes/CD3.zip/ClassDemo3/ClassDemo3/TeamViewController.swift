//
//  TeamViewController.swift
//  ClassDemo3
//
//  Created by bulko on 9/21/22.
//

import UIKit

class TeamViewController: UIViewController {
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var teamLabel: UILabel!
    
    var teamName:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        teamLabel.text = "Team selected: \(teamName)"
        let teamIndex = teams.firstIndex(of: teamName)
        cityLabel.text = "City: \(cities[teamIndex!])"
    }

}
