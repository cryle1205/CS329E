//
//  ViewController.swift
//  ClassDemo3
//
//  Created by bulko on 9/19/22.
//

import UIKit

public let teams = [
    "Dodgers", "Giants", "Cubs", "Cardinals",
    "Mets", "Braves", "Yankees", "Red Sox",
    "Rangers", "Astros", "Tigers", "Royals"]

public let cities = [
    "Los Angeles", "San Francisco", "Chicago", "St. Louis",
    "New York", "Atlanta", "New York", "Boston",
    "Texas", "Houston", "Detroit", "Kansas City"]

let textCellIdentifier = "TextCell"
let teamSegueIdentifier = "TeamSegueIdentifier"

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return teams.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let row = indexPath.row
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        cell.textLabel?.text = teams[row]
        
        if row < 6 {
            // National
            cell.detailTextLabel?.text = "National"
        } else {
            // American
            cell.detailTextLabel?.text = "American"
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = indexPath.row
        tableView.deselectRow(at: indexPath, animated: true)
        print(teams[row])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == teamSegueIdentifier,
           let destination = segue.destination as? TeamViewController,
           let teamIndex = tableView.indexPathForSelectedRow?.row {
            destination.teamName = teams[teamIndex]
        }
    }
    
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        return indexPath.row == 6 ? nil : indexPath
    }

}

