import Foundation

class Person: NSObject {
    @objc dynamic var name = "Taylor Swift"
}

let taylor = Person()

//taylor.observe(\Person.name, options: .new) {
//    person, change in
//    print("I'm now called \(change.newValue)")
//}

taylor.name = "Taylor Lautner"

taylor.observe(\Person.name, options: .old) {
    person, change in
    print("I'm now called \(change.oldValue!)")
}
