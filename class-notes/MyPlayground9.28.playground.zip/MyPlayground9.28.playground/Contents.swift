//Closure (handlers)

var myArray = ["beam", "me", "up", "scotty"]
print(myArray.sorted())

func myCompare(x:[Int],y:[Int]) -> Bool{
    return x[0] < y[0]
}
var myArray2 = [[1,2,3], [2,4,8], [9,1,7], [6,1,4]]
print(myArray2.sorted(by: myCompare))

//print(myArray2.sorted(by:{ (x:[Int],y:[Int]) -> Bool in return x[0] < y[0]}))
//sorted can detect type and Int does not need to be defined
//print(myArray2.sorted(by:{ (x,y) -> Bool in return x[0] < y[0]}))
print(myArray2.sorted(by: {$0[0] < $1[0]}))

//var a = 5
//var b = 7
//var total = a + b
//print(total) //or print(a+b)

//variadic parameters
func listSum(values:[Int]) -> Int {
    var total = 0
    
    for number in values {
        total += number
    }
    return total
}

print(listSum(values: [3,5,7,9,32,5,45]))

func listSum1(values:Int...) -> Int {
    var total = 0
    
    for number in values {
        total += number
    }
    return total
}
print(listSum1(values: 3,5,7,9,32,5,45))

//Pass by value
//pass bu reference

func exchange(a:inout Int, b:inout Int){
    var temp = a
    a = b
    b = temp
}

var x = 5
var y = 3

print("x = \(x)")
print("y = \(y)")

exchange(a:&x, b:&y)
