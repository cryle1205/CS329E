//
//  ViewController.swift
//  ClassDemo9
//
//  Created by bulko on 10/13/22.
//

import UIKit
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        demoCoreData()
    }

    func demoCoreData() {
        
        print("\n\nStarting Core Data Demo")
        
        // Remove all objects from Core Data
        clearCoreData()

        storePerson(name: "Justin Timberlake", age: 41)
        storePerson(name: "Alicia Keys", age: 41)
        storePerson(name: "Billie Eilish", age: 20)
        storePerson(name: "Carrie Underwood", age: 39)
        print("Stored four people")
        
        let fetchedResults = retrievePeople()
        
        for person in fetchedResults {
            if let personName = person.value(forKey: "name") {
                if let personAge = person.value(forKey: "age") {
                    print("Retrieved: \(personName), age \(personAge)")
                }
            }
        }
    }
    
    func storePerson(name:String,age:Int32) {
        
        let person = NSEntityDescription.insertNewObject(forEntityName: "Person", into: context)
        
        person.setValue(name, forKey: "name")
        person.setValue(age, forKey: "age")
        
        // commit the changes
        saveContext()
    }
    
    func retrievePeople() -> [NSManagedObject] {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        var fetchedResults:[NSManagedObject]? = nil
        
//        let predicate = NSPredicate(format: "name CONTAINS[c] 'ie'")
//        request.predicate = predicate
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            // if an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        return(fetchedResults)!
        
    }
    
    func clearCoreData() {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        var fetchedResults:[NSManagedObject]
        
        do {
            try fetchedResults = context.fetch(request) as! [NSManagedObject]
            
            if fetchedResults.count > 0 {
                for result:AnyObject in fetchedResults {
                    context.delete(result as! NSManagedObject)
                    print("\(result.value(forKey: "name")!) has been deleted")
                }
            }
            saveContext()
            
        } catch {
            // if an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
    }

    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
}

