// Property observers

//var x = "Initial value" {
//    willSet{ //runs first initial value
//        print("willSet: \(x)")
//    }
//    didSet { // runs after x changees
//        print("didSet: \(x)")
//    }
//}
//
//
//x = "New value"

// Generic function types

func exchange<T>(a:inout T, b:inout T){
    var temp = a
    a = b
    b = temp
}

var x = "hello"
var y = "bye"

print("x = \(x), y = \(y)")
exchange(a:&x, b:&y)
print("x = \(x), y = \(y)")
