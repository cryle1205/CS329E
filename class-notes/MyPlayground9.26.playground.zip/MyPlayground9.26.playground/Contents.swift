import SwiftUI

var greeting = "Hello, playground"

//func addThree(val:Int) -> Int {
//    return val + 3
//}
//
//let x:Int
//print(addThree(val:x))

//var value:Int?
//print(value)
//
//var value2:Int? = 5
//print(value2)
//
//var value3:Int?
//if value3 != nil {
//    print(value3)
//}


//print("Done")

//var value4:Int?
//let tenTimes = 10 * value4! //force unwrap operator
//print(tenTimes)

//var value5:Int?
//if value5 != nil {
//    let times = 10 * value5!
//    print(times)
//} else {
//    print("value not defined")
//}

//if let normal = optional, let normal2 = opt2, let normal3 = opt3 { //only works if all three have values
// <code>
//
//}

var tens:Int? = 5
var ones:Int? = 3
var twoDigitNum:Int

if let t = tens, let u = ones {
    twoDigitNum = 10*t + u
    print(twoDigitNum)
} else {
    print("tens or ones not defined")
}


//Normal Way

var x:Int? = 5
var result:Int

if x != nil {
    result = x!
} else {
    result = 0
}

print("The result is \(result)")


// advanced way
 
var x1:Int?
var result1 = x1 != nil ? x1! : 0
print("The result is \(result1)")

//expert way (for courageous Swift programmer only)

var x2:Int? = 5
var result2 = x ?? 0
print("The result is \(result2)")

//IMPLICITLY UNQRAPPED OPTIONAL
// USED WHEN YOU KNOW FOR A FACT that it will always have a value
let opt:String? = "An optional String"
print("opt =", opt) //wrapped
print("optUnwrapped =", opt!) //unwrapped

let new:String = opt!
print("new =", new)
