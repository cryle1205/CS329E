//
//  ViewController.swift
//  ClassDemo5
//
//  Created by bulko on 10/3/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var segCtrl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onSegmentChanged(_ sender: Any) {
        
        switch segCtrl.selectedSegmentIndex {
        case 0:
            textLabel.text = "First is selected"
        case 1:
            textLabel.text = "Second is selected"
        case 2:
            textLabel.text = "Third is selected"
        case 3:
            textLabel.text = "Fourth is selected"
        default:
            textLabel.text = "Error"
        }
        
    }
    
}

