// The guard statement

// guard <condition> else{
// <statement>
// }

import Foundation

print(sqrt(-3))


