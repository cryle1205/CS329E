//functions
//func funcName (arg, arg, ...) -> returnType{
//
//}
// (arg list where args are)
//argument = name, followed by a colon, followed by a type
// ACTUALLY argument = name name:type
//arg list = zero or more arguments separated by comas

func printNames(first:String, last:String){
    print("\(last), \(first)")
}

func printNames(firstName first:String, lastName last:String){
    print("\(last), \(first)")
}
// first and last are called internal names/labels
//you're going to reduce to reference the parameters here inside your code, whatever you define here as parameters are the names that you use down here, and that's consistent with everything else you've ever done before.
printNames(firstName: "Hermione", lastName: "Granger")
printNames(first:"Bill", last: "Bulko")
//use underscore if you dont want to specify _last iinstead of lastName or last
// if you want default value
func printNames3(first:String, last:String="Granger"){
    print("\(last), \(first)")
}

//concatenation
func returnGreeting(personName:String) -> String{
    let newGreeting = "Hello, " + personName + "!"
    return newGreeting
}
//without concatenation
func returnGreeting2(personName:String) -> String{
    let newGreeting = "Hello, \(personName)!"
    return newGreeting
}

print(returnGreeting(personName: "Ron"))

func findMinAndMax(myArray:[Int]) -> (min: Int, max:Int) {
    var currentMin = myArray[0]
    var currentMax = myArray[0]
    for value in myArray[1..<myArray.count]{
        if value < currentMin {
            currentMin = value
        } else if value > currentMax{
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}

let result = findMinAndMax(myArray: [3,65,4,9,2,7])
let (resultMin, resultMax) = findMinAndMax(myArray: [3,65,4,9,2,7])
print(result)
print(result.min)
print(result.max)
