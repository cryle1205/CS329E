//
//  ViewController.swift
//  ClassDemo4
//
//  Created by bulko on 9/30/22.
//

import UIKit

let choices = [
    "Simple UIAlertViewController",
    "UIAlertViewController with TextField",
    "UIAlertViewController with Multiple Buttons",
    "Standard ActionSheet",
    "Empty line"
]

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    let textCellIdentifier = "TextCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return choices.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let row = indexPath.row
        cell.textLabel?.text = choices[row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let rowValue = choices[indexPath.row]   // string from the cell
        
        switch indexPath.row {
        case 0:  // simple
            let controller = UIAlertController(
                title: "Alert Controller",
                message: rowValue,
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "Cancel",
                style: .cancel))
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default))
            present(controller, animated: true)
            
        case 1:  // with text field
            let controller = UIAlertController(
                title: "Alert Controller",
                message: rowValue,
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "Cancel",
                style: .cancel))
            controller.addTextField(configurationHandler: {
                (textField:UITextField!) in
                textField.placeholder = "Enter something"
            })
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default,
                handler: {
                    (paramAction:UIAlertAction!) in
                    if let textFieldArray = controller.textFields {
                        let textFields = textFieldArray as [UITextField]
                        let enteredText = textFields[0].text
                        print(enteredText!)
                    }
                }))
            present(controller, animated: true)
            
        case 2:  // with multiple buttons
            let controller = UIAlertController(
                title: "Alert Controller",
                message: rowValue,
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "One",
                style: .default))
            controller.addAction(UIAlertAction(
                title: "Two",
                style: .default))
            controller.addAction(UIAlertAction(
                title: "Three",
                style: .default))
            controller.addAction(UIAlertAction(
                title: "Four",
                style: .default))
            controller.addAction(UIAlertAction(
                title: "Cancel",
                style: .cancel))
            present(controller, animated: true)
            
        case 3:  // ActionSheet
            let controller = UIAlertController(
                title: "Action Sheet",
                message: rowValue,
                preferredStyle: .actionSheet)
            
            let cancelAction = UIAlertAction(
                title: "Cancel",
                style: .cancel,
                handler: {
                    (action) in print("Cancel action")
                })
            controller.addAction(cancelAction)
            
            let OKAction = UIAlertAction(
                title: "OK",
                style: .default,
                handler: {
                    (action) in print("Accept data")
                })
            controller.addAction(OKAction)
            
            let destroyAction = UIAlertAction(
                title: "Delete",
                style: .destructive,
                handler: {
                    (action) in print("Destroy data")
                })
            controller.addAction(destroyAction)
            
            present(controller, animated: true)
            
        default:  // if none of the above apply
            let controller = UIAlertController(
                title: "Unidentified Alert Type",
                message: rowValue,
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                title: "This should never happen?!",
                style: .default))
            present(controller, animated: true)
        }
        
    }
    
}

