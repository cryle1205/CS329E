//
//  MyCollectionViewCell.swift
//  ClassDemo14
//
//  Created by bulko on 11/4/22.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myLabel: UILabel!
}
