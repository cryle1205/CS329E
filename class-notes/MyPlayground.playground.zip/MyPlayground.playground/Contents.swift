import UIKit

var greeting = "Hello, playground"

var message = "Hello World"
// print brings out bottom display, but why the \n
// what is printing useful for?
print(message)


var a = 4
var b = 2
var n = a + b

// what does ... mean or ..<
var fact = 1
for i in 1 ... n+1 {
    fact = fact * i
    print("factorial of", i, "is", fact)
}

// vi demo.swift
a += 1


// Data Types
//var firstName = "Kanye"
var firstName:String = "Kanye"

// Int, Float, Double, String, Bool

// Int, Int8, Int 32, Int 64
// UInt, UInt8, UInt16, UInt32, UInt64

//var x:Int8 = 5000
//min is smallest value in class --- max is largest
var minIntValue = Int8.min
var maxIntValue = Int8.max
var minUIntValue = UInt8.min
var maxUIntValue = UInt8.max

//Float are 32 bits
//Doubles are 64 bits


