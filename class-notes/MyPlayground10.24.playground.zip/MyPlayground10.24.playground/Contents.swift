import Foundation

//let queue = DispatchQueue(label: "myQueue")
//
////in the background // runs 3x by itself
//queue.async {
//    for _ in 1...3 {
//        print("Background Thread")
//    }
//}
//
////main thread // runs 3x by itself
//for _ in 1...3 {
//    print("Main Thread")
//}

//run whole thing
//Output (sync):
//Background Thread
//Background Thread
//Background Thread
//Main Thread
//Main Thread
//Main Thread

//async output
//Background Thread
//Main Thread
//Main Thread
//Background Thread
//Main Thread
//Background Thread

let queue1 = DispatchQueue(label: "myQueue1", qos: .userInteractive)
let queue2 = DispatchQueue(label: "myQueue2", qos: .userInitiated)

//in the background // runs 3x by itself
queue1.async {
    for _ in 1...3 {
        print("first")
    }
}

queue2.async {
    for _ in 1...3 {
        print("second")
    }
}

