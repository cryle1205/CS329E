//
// Project: LeCrystal-HW7
// EID: CL44964
//
//  AddTimerViewController.swift
//  LeCrystal-HW7
//
//  Created by Crystal Le on 10/29/22.
//

import UIKit

class AddTimerViewController: UIViewController {

    var delegate: UIViewController!
    var currentTimer = Timer(event: "", location: "", time: "")
    
    @IBOutlet weak var totalTimeTextField: UITextField!
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var eventTextField: UITextField!
    @IBAction func savePressed(_ sender: Any) {
        currentTimer.event = eventTextField.text!
        currentTimer.location = locationTextField.text!
        currentTimer.time = totalTimeTextField.text!
        if (currentTimer.event != "") && (currentTimer.location != "") && (currentTimer.time != "") {
            print(currentTimer)
            let mainVC = delegate as! TimerAdder
            mainVC.addTimer(newTimer: currentTimer)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}
