//
// Project: LeCrystal-HW7
// EID: CL44964
// Course: CS329E
//  CountdownViewController.swift
//  LeCrystal-HW7
//
//  Created by Crystal Le on 10/29/22.
//

import UIKit
import Foundation

class CountdownViewController: UIViewController {
    
    let queue = DispatchQueue(label: "myQueue", qos:.background)
    var delegate: UIViewController!
    var locationName = ""
    var eventName = ""
    var timeLeft = ""
    var countTime = -1
    var index = 0
    
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var eventLabel: UILabel!
    @IBOutlet weak var remainingTimeLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        locationLabel.text = locationName
        eventLabel.text = eventName
        remainingTimeLabel.text = timeLeft
        countTime = Int(remainingTimeLabel.text!)!
        startTimer()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        let mainVC = delegate as! UpdateTimer
        mainVC.timerUpdate(currentTime: remainingTimeLabel.text!, index: index)
        self.dismiss(animated: true)
    }
    
    func startTimer() {
        queue.async {
            while (self.countTime > 0) {
                sleep(1)
                self.countTime -= 1
            }
        }
        DispatchQueue.main.async {
            self.remainingTimeLabel.text = String(self.countTime)
            self.startTimer()
        }
    }
}
