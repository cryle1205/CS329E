//
// Project: LeCrystal-HW7
// EID: CL44964
//
//  ViewController.swift
//  LeCrystal-HW7
//
//  Created by Crystal Le on 10/29/22.
//

import UIKit

class Timer {
    var event = ""
    var location = ""
    var time = ""
    
    init(event:String, location:String, time:String) {
        self.event = event
        self.location = location
        self.time = time
    }
}

protocol TimerAdder {
    func addTimer(newTimer:Timer)
}

protocol UpdateTimer {
    func timerUpdate(currentTime: String, index: Int)
}

var timerList:[Timer] = []

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, TimerAdder, UpdateTimer{
    
    @IBOutlet weak var tableView: UITableView!
    
    let textCellIdentifier = "TimerTable-ViewCell"
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return timerList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let row = indexPath.row
        cell.textLabel?.text = "Event:  \(timerList[row].event)\n\t\t\t\t\tRemaining Time(s):  \(timerList[row].time)\nLocation:  \(timerList[row].location)"
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addTimerSegue", //connect to "TextSegue"
           let addTimerVC = segue.destination as? AddTimerViewController {
            //redirect stored data to ViewController
            addTimerVC.delegate = self
        }
        if segue.identifier == "countdownSegue",
           let countdownVC = segue.destination as? CountdownViewController,  let idx = tableView.indexPathForSelectedRow?.row  {
                countdownVC.locationName = timerList[idx].location
                countdownVC.eventName = timerList[idx].event
                countdownVC.timeLeft = timerList[idx].time
                countdownVC.index = idx
                countdownVC.delegate = self
            }
        }

    func addTimer (newTimer: Timer) {
        timerList.append(newTimer)
        self.tableView.reloadData()
        //update table with new timers after hitting save
    }
    
    func timerUpdate(currentTime: String, index: Int) {
        timerList[index].time = currentTime
        self.tableView.reloadData()
    }
}

